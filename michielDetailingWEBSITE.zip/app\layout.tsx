import type { Metadata, Viewport } from "next";
import { Inter, Montserrat } from "next/font/google";

import "./globals.css";

import { MobileContactBar } from "@/components/nav/mobile-contact-bar";
import { SiteNav } from "@/components/nav/site-nav";
import { SiteFooter } from "@/components/sections/site-footer";
import { LocalBusinessJsonLd } from "@/lib/structured-data";
import { site } from "@/lib/site";

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-inter",
  display: "swap",
});

const montserrat = Montserrat({
  subsets: ["latin"],
  // Only the weights the design uses: bold on card titles, extrabold on
  // section and hero titles.
  weight: ["700", "800"],
  variable: "--font-montserrat",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: `${site.name} — Mobiele auto detailing in Breda en Goes`,
    // Inner pages set only their own name; this appends the brand.
    template: `%s — ${site.name}`,
  },
  description:
    "Mobiele auto detailing in de regio Breda en Goes. Interieurreiniging, handwas, lakcorrectie en keramische coating — ik kom naar je toe. Vraag vrijblijvend een offerte aan.",
  applicationName: site.name,
  keywords: [
    "auto detailing",
    "auto poetsen",
    "lakcorrectie",
    "keramische coating",
    "interieurreiniging auto",
    "mobiele autopoets",
    "detailing Breda",
    "detailing Goes",
  ],
  authors: [{ name: site.name, url: site.url }],
  creator: site.name,
  publisher: site.name,
  category: "automotive",
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    siteName: site.name,
    locale: "nl_NL",
    url: "/",
    title: `${site.name} — Mobiele auto detailing in Breda en Goes`,
    description:
      "Interieurreiniging, handwas, lakcorrectie en keramische coating op locatie. Werkgebied: regio Breda en regio Goes.",
  },
  twitter: {
    card: "summary_large_image",
    title: `${site.name} — Mobiele auto detailing`,
    description:
      "Interieurreiniging, handwas, lakcorrectie en keramische coating op locatie in Breda en Goes.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  // Set GOOGLE_SITE_VERIFICATION once the Search Console property is claimed.
  verification: process.env.GOOGLE_SITE_VERIFICATION
    ? { google: process.env.GOOGLE_SITE_VERIFICATION }
    : undefined,
  formatDetection: { telephone: true, address: true },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#ffffff",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="nl" className={`${inter.variable} ${montserrat.variable}`}>
      <body>
        <LocalBusinessJsonLd />

        <a
          href="#main"
          className="sr-only rounded-md bg-accent px-4 py-2 text-white focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-200"
        >
          Naar de inhoud
        </a>

        <SiteNav />

        <main id="main" className="pt-[var(--nav-h)]">
          {children}
        </main>

        <SiteFooter />

        {/* Reserves the height of the fixed bar so it cannot cover the last
            line of the footer on a phone. */}
        <div aria-hidden="true" className="h-[74px] lg:hidden" />
        <MobileContactBar />
      </body>
    </html>
  );
}
