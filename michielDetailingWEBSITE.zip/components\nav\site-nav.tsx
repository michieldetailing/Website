"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useState } from "react";

import { Logo } from "@/components/ui/logo";
import {
  CloseIcon,
  MenuIcon,
  PhoneIcon,
  WhatsAppIcon,
} from "@/components/ui/icons";
import { navLinks } from "@/lib/nav-links";
import { site, telUrl, whatsappUrl } from "@/lib/site";

export function SiteNav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);

  // A fixed-position panel over a scrolling page reads as broken; lock the
  // body while it is open.
  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const isActive = (href: string) =>
    pathname === href || pathname.startsWith(`${href}/`);

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-100 border-b border-border bg-surface/90 backdrop-blur-md">
        {/* ── Logo bar ── */}
        <div className="mx-auto flex h-[72px] w-full max-w-[1200px] items-center px-6 lg:h-[68px] lg:px-8 xl:px-15">
          {/* Left and right blocks are equal-width so the logo lands optically
              centred on desktop, not just centred within the leftover space. */}
          <div className="hidden flex-1 lg:block">
            <p className="text-[12.5px] font-medium tracking-wide text-ink-dim">
              Mobiele auto detailing · Breda &amp; Goes
            </p>
          </div>

          <Link
            href="/"
            aria-label="Michiel Detailing — naar de homepage"
            className="mx-auto flex items-center gap-3 lg:mx-0"
          >
            <Logo size={44} className="rounded-[10px] lg:hidden" />
            <Logo size={52} className="hidden rounded-xl lg:block" />
            <span className="sr-only">Michiel Detailing</span>
          </Link>

          <div className="hidden flex-1 items-center justify-end gap-2 lg:flex">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary px-4 py-2.5 text-[13px]"
            >
              <WhatsAppIcon size={17} />
              WhatsApp
            </a>
            <a href={telUrl} className="btn-primary px-4 py-2.5 text-[13px]">
              <PhoneIcon size={16} />
              {site.phoneDisplay}
            </a>
          </div>

          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-expanded={open}
            aria-controls="mobiel-menu"
            aria-label={open ? "Menu sluiten" : "Menu openen"}
            className="absolute right-5 rounded-lg p-2 text-ink lg:hidden"
          >
            {open ? <CloseIcon size={22} /> : <MenuIcon size={22} />}
          </button>
        </div>

        {/* ── Link row (desktop only) ── */}
        <nav
          aria-label="Hoofdmenu"
          className="hidden border-t border-border lg:block"
        >
          <div className="mx-auto flex h-10 w-full max-w-[1200px] items-center justify-center gap-8 px-8 xl:px-15">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                aria-current={isActive(link.href) ? "page" : undefined}
                className={`text-[13.5px] font-medium transition-colors ${
                  isActive(link.href)
                    ? "text-accent-text"
                    : "text-ink-dim hover:text-ink"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/offerte"
              className="text-[13.5px] font-semibold text-accent-text underline decoration-accent-light/40 underline-offset-4 hover:decoration-accent-light"
            >
              Offerte aanvragen
            </Link>
          </div>
        </nav>
      </header>

      {/* ── Mobile panel ──
          A sibling of <header>, not a child. The header carries
          `backdrop-blur`, and a backdrop-filter makes an element the containing
          block for its `position: fixed` descendants — nested inside, this
          panel's top/bottom would resolve against the 72px header rather than
          the viewport and collapse to a sliver. */}
      {open ? (
        <nav
          id="mobiel-menu"
          aria-label="Hoofdmenu"
          className="fixed inset-x-0 top-[var(--nav-h)] bottom-0 z-99 overflow-y-auto border-t border-border bg-surface px-6 py-6 lg:hidden"
        >
          {/* Each link closes the panel itself. Watching `pathname` in an
              effect instead would mean a second render pass on every
              navigation, and would miss the case where someone taps the page
              they are already on. */}
          <ul className="flex flex-col">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  onClick={close}
                  aria-current={isActive(link.href) ? "page" : undefined}
                  className={`block border-b border-border py-4 text-[17px] font-semibold ${
                    isActive(link.href) ? "text-accent-text" : "text-ink"
                  }`}
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>

          <Link
            href="/offerte"
            onClick={close}
            className="btn-primary mt-6 w-full"
          >
            Offerte aanvragen
          </Link>

          <div className="mt-4 grid grid-cols-2 gap-3">
            <a href={telUrl} onClick={close} className="btn-secondary">
              <PhoneIcon size={17} />
              Bellen
            </a>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={close}
              className="btn-secondary"
            >
              <WhatsAppIcon size={17} />
              WhatsApp
            </a>
          </div>

          <p className="mt-8 text-[13px] text-ink-dim">
            {site.phoneDisplay}
            <br />
            {site.email}
          </p>
        </nav>
      ) : null}
    </>
  );
}
