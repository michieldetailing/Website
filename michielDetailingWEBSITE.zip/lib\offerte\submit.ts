import { isMailConfigured, sendQuoteEmails } from "./mailer";
import { checkRateLimit } from "./rate-limit";
import {
  HONEYPOT_FIELD,
  MIN_FILL_MS,
  quoteSchema,
  toSubmission,
} from "./schema";

export type SubmitOutcome =
  | { ok: true }
  | { ok: false; reason: "invalid"; fieldErrors: Record<string, string[]> }
  | { ok: false; reason: "rate_limited" }
  | { ok: false; reason: "not_configured" }
  | { ok: false; reason: "send_failed" };

/**
 * The whole quote pipeline in one place, kept free of HTTP specifics so the
 * route handler stays thin and a future server action could reuse it.
 */
export async function submitQuote(
  payload: unknown,
  context: { ip: string; now?: number },
): Promise<SubmitOutcome> {
  const now = context.now ?? Date.now();

  const parsed = quoteSchema.safeParse(payload);
  if (!parsed.success) {
    return {
      ok: false,
      reason: "invalid",
      fieldErrors: parsed.error.flatten().fieldErrors as Record<
        string,
        string[]
      >,
    };
  }

  const input = parsed.data;

  // Silently accept bot submissions: reporting the rejection would tell an
  // attacker exactly which signal caught them.
  const trippedHoneypot = input[HONEYPOT_FIELD].length > 0;
  const tooFast = now - input.startedAt < MIN_FILL_MS;
  if (trippedHoneypot || tooFast) {
    return { ok: true };
  }

  if (!checkRateLimit(context.ip, now)) {
    return { ok: false, reason: "rate_limited" };
  }

  if (!isMailConfigured()) {
    console.error(
      "Quote form submitted but RESEND_API_KEY is missing; the enquiry was not delivered.",
    );
    return { ok: false, reason: "not_configured" };
  }

  try {
    await sendQuoteEmails(toSubmission(input));
    return { ok: true };
  } catch (error) {
    console.error("Quote form send failed:", error);
    return { ok: false, reason: "send_failed" };
  }
}
