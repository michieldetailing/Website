import type { Metadata } from "next";
import Link from "next/link";

import { CtaBanner } from "@/components/sections/cta-banner";
import { Container } from "@/components/ui/container";
import { ArrowRightIcon, CheckIcon } from "@/components/ui/icons";
import { PageHero } from "@/components/ui/page-hero";
import { Photo } from "@/components/ui/photo";
import { Reveal } from "@/components/ui/reveal";
import { services } from "@/lib/services";
import { BreadcrumbJsonLd, ServiceListJsonLd } from "@/lib/structured-data";

export const metadata: Metadata = {
  title: "Diensten",
  description:
    "Interieurreiniging, handwas, lakcorrectie en keramische coating — mobiel uitgevoerd in de regio Breda en Goes. Lees per dienst wat er precies gebeurt.",
  alternates: { canonical: "/diensten" },
};

export default function ServicesPage() {
  return (
    <>
      <ServiceListJsonLd />
      <BreadcrumbJsonLd
        trail={[
          { name: "Home", path: "" },
          { name: "Diensten", path: "/diensten" },
        ]}
      />

      <PageHero
        eyebrow="Diensten"
        title="Wat ik met je auto doe"
        breadcrumb={[{ label: "Home", href: "/" }]}
        lead="Vier categorieën, van een frisse beurt tot volledig gecorrigeerde en gecoate lak. Per dienst lees je wat er gebeurt, waarom het zo gaat, en welke pakketten erbij horen."
      />

      <section className="bg-surface py-16 lg:py-24">
        <Container>
          <div className="flex flex-col gap-16 lg:gap-24">
            {services.map((service, index) => (
              <Reveal key={service.id}>
                <article
                  className={`grid items-center gap-10 lg:grid-cols-2 lg:gap-16 ${
                    index % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""
                  }`}
                >
                  <Photo
                    shot={`${service.title}: representatieve foto van deze behandeling`}
                    ratio="4 / 3"
                    sizes="(max-width: 1024px) 100vw, 46vw"
                  />

                  <div>
                    <p className="eyebrow">
                      {String(index + 1).padStart(2, "0")}
                    </p>
                    <h2 className="section-title mt-3 text-balance">
                      {service.title}
                    </h2>
                    <p className="mt-4 text-[16px] leading-[1.7] text-ink-dim">
                      {service.intro}
                    </p>

                    <ul className="mt-6 flex flex-col gap-2.5">
                      {service.highlights.map((line) => (
                        <li
                          key={line}
                          className="flex gap-2.5 text-[14.5px] leading-snug text-ink-dim"
                        >
                          <CheckIcon
                            size={16}
                            className="mt-0.5 shrink-0 text-accent-light"
                          />
                          {line}
                        </li>
                      ))}
                    </ul>

                    <Link
                      href={`/diensten/${service.slug}`}
                      className="btn-primary mt-8"
                    >
                      Alles over {service.title.toLowerCase()}
                      <ArrowRightIcon size={17} />
                    </Link>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      <CtaBanner />
    </>
  );
}
