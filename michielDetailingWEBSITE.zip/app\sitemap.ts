import type { MetadataRoute } from "next";

import { areas } from "@/lib/areas";
import { services } from "@/lib/services";
import { site } from "@/lib/site";

/**
 * Priorities reflect what actually earns the business money: the quote form
 * and the price list convert, the town pages are the entry points from local
 * search, and the privacy statement is there because it has to be.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();

  // `as const` matters: without it the mapped `changeFrequency` widens to
  // `string` and no longer satisfies the union MetadataRoute.Sitemap wants.
  const staticRoutes: MetadataRoute.Sitemap = (
    [
      { url: "/", priority: 1, changeFrequency: "monthly" },
      { url: "/diensten", priority: 0.9, changeFrequency: "monthly" },
      { url: "/prijzen", priority: 0.9, changeFrequency: "monthly" },
      { url: "/offerte", priority: 0.9, changeFrequency: "yearly" },
      { url: "/werkgebied", priority: 0.8, changeFrequency: "monthly" },
      { url: "/zakelijk", priority: 0.8, changeFrequency: "monthly" },
      { url: "/over-mij", priority: 0.6, changeFrequency: "yearly" },
      { url: "/privacy", priority: 0.2, changeFrequency: "yearly" },
    ] as const
  ).map((route) => ({ ...route, url: `${site.url}${route.url}`, lastModified }));

  const serviceRoutes: MetadataRoute.Sitemap = services.map((service) => ({
    url: `${site.url}/diensten/${service.slug}`,
    lastModified,
    changeFrequency: "monthly",
    priority: 0.8,
  }));

  const areaRoutes: MetadataRoute.Sitemap = areas.map((area) => ({
    url: `${site.url}/werkgebied/${area.slug}`,
    lastModified,
    changeFrequency: "monthly",
    // The two bases are the pages most likely to rank, so they lead.
    priority: area.isBase ? 0.8 : 0.7,
  }));

  return [...staticRoutes, ...serviceRoutes, ...areaRoutes];
}
