import type { Metadata } from "next";
import Link from "next/link";

import { CtaBanner } from "@/components/sections/cta-banner";
import { Container } from "@/components/ui/container";
import { ArrowRightIcon, MapPinIcon, VanIcon } from "@/components/ui/icons";
import { PageHero } from "@/components/ui/page-hero";
import { Reveal } from "@/components/ui/reveal";
import { areasInRegion, regionLabels, regions } from "@/lib/areas";
import { site } from "@/lib/site";
import { BreadcrumbJsonLd } from "@/lib/structured-data";

export const metadata: Metadata = {
  title: "Werkgebied",
  description: `Mobiele auto detailing in de regio Breda en de regio Goes, tot ${site.maxTravelKm} km rond beide plaatsen. Bekijk of jouw plaats erbij zit.`,
  alternates: { canonical: "/werkgebied" },
};

export default function AreasPage() {
  return (
    <>
      <BreadcrumbJsonLd
        trail={[
          { name: "Home", path: "" },
          { name: "Werkgebied", path: "/werkgebied" },
        ]}
      />

      <PageHero
        eyebrow="Werkgebied"
        title="Waar ik kom"
        breadcrumb={[{ label: "Home", href: "/" }]}
        lead={`Ik werk vanuit twee bases: Breda in Noord-Brabant en Goes in Zeeland. Vanaf beide plaatsen rijd ik tot ${site.maxTravelKm} km. De plaatsen hieronder hebben hun eigen pagina — staat die van jou er niet bij, maar zit je binnen die afstand? Vraag het gewoon.`}
      />

      <section className="bg-surface py-16 lg:py-20">
        <Container>
          <div className="grid gap-8 lg:grid-cols-2">
            {regions.map((region, index) => (
              <Reveal key={region} delay={index * 80}>
                <div className="h-full rounded-lg border border-border bg-surface-2 p-7 lg:p-8">
                  <div className="flex items-center gap-2.5">
                    <MapPinIcon size={20} className="text-accent-light" />
                    <h2 className="card-title text-[21px]">
                      {regionLabels[region].name}
                    </h2>
                  </div>
                  <p className="mt-2 text-[13.5px] text-ink-faint">
                    {regionLabels[region].province} · straal{" "}
                    {site.maxTravelKm} km
                  </p>

                  <ul className="mt-7 flex flex-col">
                    {areasInRegion(region).map((area) => (
                      <li key={area.slug}>
                        <Link
                          href={`/werkgebied/${area.slug}`}
                          className="group flex items-center justify-between gap-4 border-b border-border py-3.5"
                        >
                          <span className="flex items-baseline gap-2.5">
                            <span className="text-[15.5px] font-semibold text-ink">
                              {area.name}
                            </span>
                            {area.isBase ? (
                              <span className="rounded-full bg-brand-tint px-2 py-0.5 text-[10.5px] font-bold tracking-wide text-accent-text uppercase">
                                Basis
                              </span>
                            ) : (
                              <span className="text-[12.5px] text-ink-faint">
                                ± {area.distanceKm} km
                              </span>
                            )}
                          </span>
                          <ArrowRightIcon
                            size={15}
                            className="shrink-0 text-accent-light transition-transform group-hover:translate-x-0.5"
                          />
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-10 flex items-start gap-4 rounded-lg border border-border bg-brand-tint-soft p-6">
            <VanIcon size={22} className="mt-0.5 shrink-0 text-accent-light" />
            <div>
              <h2 className="card-title text-[17px]">Over reiskosten</h2>
              <p className="mt-2 max-w-[70ch] text-[14.5px] leading-relaxed text-ink-dim">
                Reiskosten reken ik apart, op basis van de afstand tot de
                dichtstbijzijnde basis. Je hoort het bedrag vooraf in je offerte,
                dus het totaal staat vast voordat ik vertrek. Zitten er meerdere
                auto&apos;s in dezelfde straat of bij hetzelfde bedrijf, dan
                deel ik de reiskosten — dat scheelt iedereen geld.
              </p>
            </div>
          </Reveal>
        </Container>
      </section>

      <CtaBanner
        title="Zit jouw plaats erbij?"
        body="Geef je postcode door bij de aanvraag, dan reken ik de reiskosten meteen mee in je offerte."
      />
    </>
  );
}
