"use client";

import {
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";

import { CheckIcon, WhatsAppIcon } from "@/components/ui/icons";
import { packageGroups, groupLabels, packagesInGroup } from "@/lib/packages";
import { whatsappUrl } from "@/lib/site";
import {
  HONEYPOT_FIELD,
  customerTypes,
  paintConditionLabels,
  paintConditions,
  vehicleSizeLabels,
  vehicleSizes,
  workspaceLabels,
  workspaceOptions,
  type CustomerType,
} from "@/lib/offerte/schema";

type Status = "idle" | "sending" | "sent" | "error";

const errorMessages: Record<string, string> = {
  invalid: "Er ontbreekt nog iets. Loop de rood gemarkeerde velden even na.",
  rate_limited:
    "Er zijn net te veel aanvragen vanaf dit adres verstuurd. Probeer het over een paar minuten opnieuw, of bel me gewoon even.",
  not_configured:
    "Het formulier kan op dit moment geen mail versturen. Bel of app me even, dan pak ik het direct op.",
  send_failed:
    "Het versturen is misgegaan. Probeer het nog eens, of bel of app me even.",
};

function Field({
  label,
  htmlFor,
  hint,
  required,
  children,
}: {
  label: string;
  htmlFor: string;
  hint?: string;
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label
        htmlFor={htmlFor}
        className="text-[13.5px] font-semibold text-ink"
      >
        {label}
        {required ? (
          <span className="text-accent-text" aria-hidden="true">
            {" "}
            *
          </span>
        ) : (
          // The leading space is for screen readers: without it the accessible
          // name concatenates to "Bedrijfsnaamoptioneel".
          <span className="ml-1.5 text-[12px] font-normal text-ink-faint">
            {" "}
            optioneel
          </span>
        )}
      </label>
      {children}
      {hint ? <p className="text-[12.5px] text-ink-faint">{hint}</p> : null}
    </div>
  );
}

const inputClass =
  "w-full rounded-lg border border-border-strong bg-surface px-3.5 py-2.5 text-[15px] text-ink placeholder:text-ink-faint focus:border-accent focus:outline-none";

export function QuoteForm({
  defaultPackage = "onbekend",
  defaultCustomerType = "particulier",
}: {
  defaultPackage?: string;
  defaultCustomerType?: CustomerType;
}) {
  const [customerType, setCustomerType] =
    useState<CustomerType>(defaultCustomerType);
  const [status, setStatus] = useState<Status>("idle");
  const [errorReason, setErrorReason] = useState<string | null>(null);
  const [invalidFields, setInvalidFields] = useState<string[]>([]);

  // Stamped on mount so the server can reject sub-second submissions. It sits
  // in a ref set from an effect rather than in render: Date.now() is impure,
  // and a re-render would otherwise move the start time forward and make a
  // genuine visitor look like a bot.
  const startedAtRef = useRef(0);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    startedAtRef.current = Date.now();
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (status === "sending") return;

    setStatus("sending");
    setErrorReason(null);
    setInvalidFields([]);

    const data = new FormData(event.currentTarget);
    const payload = {
      customerType,
      name: data.get("name"),
      email: data.get("email"),
      phone: data.get("phone"),
      company: data.get("company") ?? "",
      postcode: data.get("postcode"),
      city: data.get("city"),
      carMake: data.get("carMake"),
      carModel: data.get("carModel"),
      carYear: data.get("carYear") ?? "",
      vehicleSize: data.get("vehicleSize"),
      packageSlug: data.get("packageSlug"),
      paintCondition: data.get("paintCondition"),
      workspace: data.get("workspace"),
      hasPower: data.get("hasPower") === "on",
      hasWater: data.get("hasWater") === "on",
      preferredDate: data.get("preferredDate") ?? "",
      message: data.get("message") ?? "",
      startedAt: startedAtRef.current,
      [HONEYPOT_FIELD]: data.get(HONEYPOT_FIELD) ?? "",
    };

    try {
      const response = await fetch("/api/offerte", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();

      if (result.ok) {
        setStatus("sent");
        formRef.current?.reset();
        return;
      }

      setStatus("error");
      setErrorReason(result.reason ?? "send_failed");
      setInvalidFields(Object.keys(result.fieldErrors ?? {}));
    } catch {
      setStatus("error");
      setErrorReason("send_failed");
    }
  }

  if (status === "sent") {
    return (
      <div className="rounded-lg border border-accent bg-brand-tint-soft p-8 text-center lg:p-10">
        <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-accent text-white">
          <CheckIcon size={24} />
        </span>
        <h2 className="section-title mt-5 text-[26px]">Je aanvraag is binnen</h2>
        <p className="mx-auto mt-4 max-w-[52ch] text-[15.5px] leading-[1.7] text-ink-dim">
          Je krijgt een bevestiging in je mailbox. Ik kijk ernaar en stuur je
          binnen één werkdag een prijs, inclusief reiskosten.
        </p>
        <p className="mx-auto mt-4 max-w-[52ch] text-[15.5px] leading-[1.7] text-ink-dim">
          Wil je het versnellen? Stuur me een paar foto&apos;s van je lak en
          interieur via WhatsApp — dan kan ik veel preciezer inschatten wat je
          auto nodig heeft.
        </p>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-primary mt-7"
        >
          <WhatsAppIcon size={18} />
          Foto&apos;s sturen via WhatsApp
        </a>
      </div>
    );
  }

  const fieldError = (name: string) =>
    invalidFields.includes(name) ? "border-red-500" : "";

  return (
    <form
      ref={formRef}
      onSubmit={handleSubmit}
      noValidate={false}
      className="flex flex-col gap-10"
    >
      {/* ── Customer type ── */}
      <fieldset>
        <legend className="text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
          1. Voor wie
        </legend>
        <div className="mt-4 grid grid-cols-2 gap-3">
          {customerTypes.map((type) => (
            <label
              key={type}
              className={`cursor-pointer rounded-lg border px-4 py-3.5 text-center text-[14.5px] font-semibold transition-colors ${
                customerType === type
                  ? "border-accent bg-brand-tint-soft text-accent-text"
                  : "border-border-strong bg-surface text-ink-dim hover:border-accent"
              }`}
            >
              <input
                type="radio"
                name="customerTypeChoice"
                value={type}
                checked={customerType === type}
                onChange={() => setCustomerType(type)}
                className="sr-only"
              />
              {type === "zakelijk" ? "Zakelijk" : "Particulier"}
            </label>
          ))}
        </div>
        <p className="mt-2.5 text-[12.5px] text-ink-faint">
          {customerType === "zakelijk"
            ? "Je krijgt een prijs exclusief btw en een factuur met btw-specificatie."
            : "Je krijgt een prijs inclusief btw, zoals op de prijzenpagina."}
        </p>
      </fieldset>

      {/* ── Contact ── */}
      <fieldset>
        <legend className="text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
          2. Contactgegevens
        </legend>
        <div className="mt-4 grid gap-5 sm:grid-cols-2">
          <Field label="Naam" htmlFor="name" required>
            <input
              id="name"
              name="name"
              required
              autoComplete="name"
              className={`${inputClass} ${fieldError("name")}`}
              placeholder="Voor- en achternaam"
            />
          </Field>

          {customerType === "zakelijk" ? (
            <Field label="Bedrijfsnaam" htmlFor="company">
              <input
                id="company"
                name="company"
                autoComplete="organization"
                className={inputClass}
                placeholder="Naam van je bedrijf"
              />
            </Field>
          ) : null}

          <Field label="E-mailadres" htmlFor="email" required>
            <input
              id="email"
              name="email"
              type="email"
              required
              autoComplete="email"
              className={`${inputClass} ${fieldError("email")}`}
              placeholder="jij@voorbeeld.nl"
            />
          </Field>

          <Field
            label="Telefoonnummer"
            htmlFor="phone"
            required
            hint="Ik bel of app liever even dan dat we vijf mails heen en weer sturen."
          >
            <input
              id="phone"
              name="phone"
              type="tel"
              required
              autoComplete="tel"
              className={`${inputClass} ${fieldError("phone")}`}
              placeholder="06 12 34 56 78"
            />
          </Field>

          <Field label="Postcode" htmlFor="postcode" required>
            <input
              id="postcode"
              name="postcode"
              required
              autoComplete="postal-code"
              className={`${inputClass} ${fieldError("postcode")}`}
              placeholder="4811 AA"
            />
          </Field>

          <Field
            label="Plaats"
            htmlFor="city"
            required
            hint="Hiermee reken ik de reiskosten uit."
          >
            <input
              id="city"
              name="city"
              required
              autoComplete="address-level2"
              className={`${inputClass} ${fieldError("city")}`}
              placeholder="Breda"
            />
          </Field>
        </div>
      </fieldset>

      {/* ── Vehicle ── */}
      <fieldset>
        <legend className="text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
          3. Je auto
        </legend>
        <div className="mt-4 grid gap-5 sm:grid-cols-2">
          <Field label="Merk" htmlFor="carMake" required>
            <input
              id="carMake"
              name="carMake"
              required
              className={`${inputClass} ${fieldError("carMake")}`}
              placeholder="Volkswagen"
            />
          </Field>

          <Field label="Model" htmlFor="carModel" required>
            <input
              id="carModel"
              name="carModel"
              required
              className={`${inputClass} ${fieldError("carModel")}`}
              placeholder="Golf"
            />
          </Field>

          <Field label="Bouwjaar" htmlFor="carYear">
            <input
              id="carYear"
              name="carYear"
              inputMode="numeric"
              maxLength={4}
              className={inputClass}
              placeholder="2019"
            />
          </Field>

          <Field label="Formaat" htmlFor="vehicleSize" required>
            <select
              id="vehicleSize"
              name="vehicleSize"
              required
              defaultValue="middel"
              className={inputClass}
            >
              {vehicleSizes.map((size) => (
                <option key={size} value={size}>
                  {vehicleSizeLabels[size]}
                </option>
              ))}
            </select>
          </Field>

          <Field
            label="Staat van de lak"
            htmlFor="paintCondition"
            required
            hint="Geen idee? Kies de laatste optie — dan beoordeel ik het."
          >
            <select
              id="paintCondition"
              name="paintCondition"
              required
              defaultValue="onbekend"
              className={inputClass}
            >
              {paintConditions.map((condition) => (
                <option key={condition} value={condition}>
                  {paintConditionLabels[condition]}
                </option>
              ))}
            </select>
          </Field>

          <Field
            label="Welk pakket"
            htmlFor="packageSlug"
            required
            hint="Weet je het niet zeker? Kies 'weet ik nog niet' — ik adviseer wat past."
          >
            <select
              id="packageSlug"
              name="packageSlug"
              required
              defaultValue={defaultPackage}
              className={inputClass}
            >
              <option value="onbekend">Weet ik nog niet</option>
              {packageGroups.map((group) => (
                <optgroup key={group} label={groupLabels[group].title}>
                  {packagesInGroup(group).map((item) => (
                    <option key={item.slug} value={item.slug}>
                      {item.name}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
          </Field>
        </div>
      </fieldset>

      {/* ── Location ── */}
      <fieldset>
        <legend className="text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
          4. Waar ik kan werken
        </legend>
        <p className="mt-2 max-w-[62ch] text-[13.5px] leading-relaxed text-ink-dim">
          Ik kom naar jou toe, dus dit bepaalt wat er mogelijk is. Polijsten en
          coaten vragen een droge, beschutte plek; wassen kan vrijwel overal.
        </p>

        <div className="mt-4 grid gap-5 sm:grid-cols-2">
          <Field label="Type plek" htmlFor="workspace" required>
            <select
              id="workspace"
              name="workspace"
              required
              defaultValue="oprit"
              className={inputClass}
            >
              {workspaceOptions.map((option) => (
                <option key={option} value={option}>
                  {workspaceLabels[option]}
                </option>
              ))}
            </select>
          </Field>

          <Field
            label="Gewenste periode"
            htmlFor="preferredDate"
            hint="Bijvoorbeeld 'week van 8 september' of 'zo snel mogelijk'."
          >
            <input
              id="preferredDate"
              name="preferredDate"
              className={inputClass}
              placeholder="Zo snel mogelijk"
            />
          </Field>
        </div>

        <div className="mt-5 flex flex-col gap-3">
          <label className="flex cursor-pointer items-center gap-3 text-[14.5px] text-ink">
            <input
              type="checkbox"
              name="hasPower"
              defaultChecked
              className="h-4.5 w-4.5 rounded border-border-strong accent-[#1b3a63]"
            />
            Er is een stopcontact beschikbaar
          </label>
          <label className="flex cursor-pointer items-center gap-3 text-[14.5px] text-ink">
            <input
              type="checkbox"
              name="hasWater"
              defaultChecked
              className="h-4.5 w-4.5 rounded border-border-strong accent-[#1b3a63]"
            />
            Er is een waterkraan beschikbaar
          </label>
        </div>
      </fieldset>

      {/* ── Message ── */}
      <fieldset>
        <legend className="text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
          5. Nog iets te melden
        </legend>
        <div className="mt-4">
          <Field
            label="Bericht"
            htmlFor="message"
            hint="Vlekken, geurtjes, een specifieke kras, huisdieren in de auto — alles wat helpt."
          >
            <textarea
              id="message"
              name="message"
              rows={5}
              className={`${inputClass} resize-y`}
              placeholder="Bijvoorbeeld: hond rijdt regelmatig mee in de kofferbak, en er zit een kras op de achterklep."
            />
          </Field>
        </div>
      </fieldset>

      {/* Honeypot. Hidden from people, irresistible to bots. */}
      <div aria-hidden="true" className="absolute -left-[9999px]">
        <label htmlFor={HONEYPOT_FIELD}>Laat dit veld leeg</label>
        <input
          id={HONEYPOT_FIELD}
          name={HONEYPOT_FIELD}
          tabIndex={-1}
          autoComplete="off"
        />
      </div>

      {status === "error" && errorReason ? (
        <p
          role="alert"
          className="rounded-lg border border-red-300 bg-red-50 px-4 py-3 text-[14px] text-red-800"
        >
          {errorMessages[errorReason] ?? errorMessages.send_failed}
        </p>
      ) : null}

      <div className="flex flex-col gap-4 border-t border-border pt-7 sm:flex-row sm:items-center sm:justify-between">
        <p className="max-w-[42ch] text-[12.5px] leading-relaxed text-ink-faint">
          Je gegevens gebruik ik alleen om je aanvraag te beantwoorden. Zie de{" "}
          <a
            href="/privacy"
            className="underline underline-offset-2 hover:text-accent-text"
          >
            privacyverklaring
          </a>
          .
        </p>
        <button
          type="submit"
          disabled={status === "sending"}
          className="btn-primary shrink-0 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {status === "sending" ? "Versturen…" : "Aanvraag versturen"}
        </button>
      </div>
    </form>
  );
}
