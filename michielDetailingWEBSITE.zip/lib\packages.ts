import { site } from "./site";

/**
 * The price list, transcribed from "Michiel Detailing Package Prices".
 *
 * Prices are stored **excluding VAT**, exactly as they were quoted, and the
 * inclusive figure is derived. That direction matters: the excl. figure is the
 * one Michiel works from and the one the business page shows, while Dutch
 * consumer law requires the incl. figure on everything aimed at private
 * customers. Deriving rather than storing both keeps them from drifting apart.
 */

export const packageGroups = [
  "los",
  "combi",
  "correctie",
  "coating",
  "zakelijk",
] as const;

export type PackageGroup = (typeof packageGroups)[number];

export const groupLabels: Record<
  PackageGroup,
  { title: string; blurb: string }
> = {
  los: {
    title: "Losse behandelingen",
    blurb:
      "Eén onderdeel van de auto, grondig aangepakt. Ideaal als de rest al in orde is.",
  },
  combi: {
    title: "Binnen én buiten",
    blurb:
      "De hele auto in één beurt. De meest gekozen optie voor een auto die weer fris moet.",
  },
  correctie: {
    title: "Met lakcorrectie",
    blurb:
      "Machinaal polijsten om krassen en swirls uit de lak te halen. Hoe meer stappen, hoe dieper de correctie en hoe hoger de glans.",
  },
  coating: {
    title: "Keramische coating",
    blurb:
      "Lakcorrectie plus een keramische laag die de lak beschermt en het wassen jarenlang makkelijker maakt.",
  },
  zakelijk: {
    title: "Zakelijk",
    blurb:
      "Voor garages, autobedrijven en wagenparken. Vaste stukprijs, korte doorlooptijd.",
  },
};

export interface DetailPackage {
  id: string;
  slug: string;
  name: string;
  group: PackageGroup;
  /** Euro, excluding 21% VAT. */
  priceExcl: number;
  /** Human-readable working time, as quoted. */
  duration: string;
  /** One line explaining who this is for. */
  summary: string;
  /** What actually happens to the car, in plain Dutch. */
  includes: string[];
}

export const packages: DetailPackage[] = [
  {
    id: "interieur-compleet",
    slug: "interieur-compleet",
    name: "Interieur compleet",
    group: "los",
    priceExcl: 90,
    duration: "1–2 uur",
    summary:
      "Het hele interieur gereinigd, van dashboard tot kofferbak, inclusief leder.",
    includes: [
      "Volledig uitzuigen: stoelen, vloer, kofferbak en naden",
      "Dashboard, middenconsole, panelen en knoppen gereinigd",
      "Leder gereinigd en gevoed, of stof behandeld",
      "Ruiten aan de binnenzijde streeploos",
      "Deurstijlen en drempels meegenomen",
    ],
  },
  {
    id: "exterieur-compleet",
    slug: "exterieur-compleet",
    name: "Exterieur compleet",
    group: "los",
    priceExcl: 90,
    duration: "1–2 uur",
    summary:
      "Een veilige, krasvrije wasbeurt met velgen, ontijzering en bandendressing.",
    includes: [
      "Voorwas met sneeuwschuim, daarna handwas volgens de twee-emmermethode",
      "Velgen en wielkasten apart gereinigd",
      "Vliegroest en industriële neerslag verwijderd",
      "Banden en kunststof voorzien van dressing",
      "Streeploos gedroogd, ruiten en spiegels nagelopen",
    ],
  },
  {
    id: "velgen-zuurbehandeling",
    slug: "velgen-en-zuurbehandeling",
    name: "Velgen- en zuurbehandeling",
    group: "los",
    priceExcl: 95,
    duration: "1–2 uur",
    summary:
      "Voor velgen en lak die met een gewone wasbeurt niet meer schoon komen.",
    includes: [
      "Velgen behandeld met zure velgreiniger, binnen- en buitenzijde",
      "Ingebrande remstofresten losgeweekt en verwijderd",
      "Vliegroest van de gehele lak verwijderd",
      "Aanslag en industriële neerslag chemisch gedecontamineerd",
      "Afgesloten met een handwas en bandendressing",
    ],
  },
  {
    id: "lederbehandeling",
    slug: "lederbehandeling",
    name: "Lederbehandeling",
    group: "los",
    priceExcl: 60,
    duration: "1 uur",
    summary:
      "Leder dat vuil, dof of stug aanvoelt weer schoon, soepel en beschermd.",
    includes: [
      "Leder gereinigd met een pH-neutrale lederreiniger",
      "Vuil uit de nerf geborsteld zonder de toplaag aan te tasten",
      "Gevoed en beschermd tegen uitdroging en uv",
      "Stiknaden en zijwangen apart nagelopen",
    ],
  },
  {
    id: "stoelen-extraheren",
    slug: "stoelen-extraheren",
    name: "Stoelen extraheren",
    group: "los",
    priceExcl: 60,
    duration: "1 uur",
    summary:
      "Vlekken en geurtjes uit stoffen bekleding trekken in plaats van uitwrijven.",
    includes: [
      "Bekleding ingesproeid met reiniger en ingeborsteld",
      "Vuil en vocht met een extractor uit de vezel gezogen",
      "Vlekken van koffie, modder en huisdieren aangepakt",
      "Zo droog mogelijk achtergelaten zodat de auto snel weer bruikbaar is",
    ],
  },
  {
    id: "interieur-exterieur",
    slug: "interieur-en-exterieur",
    name: "Interieur & exterieur compleet",
    group: "combi",
    priceExcl: 225,
    duration: "3–4 uur",
    summary:
      "De hele auto in één beurt. Binnen en buiten volledig, zonder lakcorrectie.",
    includes: [
      "Alles uit Interieur compleet",
      "Alles uit Exterieur compleet",
      "Ontijzering van lak en velgen",
      "Kunststof buitenzijde behandeld",
      "De meest gekozen beurt voor een auto die weer als nieuw moet aanvoelen",
    ],
  },
  {
    id: "exterieur-1-staps",
    slug: "exterieur-1-staps-lakcorrectie",
    name: "Exterieur + 1-staps lakcorrectie",
    group: "correctie",
    priceExcl: 270,
    duration: "6 uur",
    summary:
      "Eén polijststap die de meeste swirls wegneemt en de glans flink terugbrengt.",
    includes: [
      "Volledige wasbeurt en chemische decontaminatie vooraf",
      "Lak machinaal gepolijst in één stap",
      "Circa 50–70% van de fijne krassen en swirls verdwenen",
      "Merkbaar diepere kleur en scherpere reflectie",
      "Afgewerkt met bandendressing en ruiten",
    ],
  },
  {
    id: "exterieur-2-staps",
    slug: "exterieur-2-staps-lakcorrectie",
    name: "Exterieur + 2-staps lakcorrectie",
    group: "correctie",
    priceExcl: 360,
    duration: "8 uur",
    summary:
      "Snijden en daarna finishen: diepere krassen eruit, hoogglans erin.",
    includes: [
      "Volledige wasbeurt en chemische decontaminatie vooraf",
      "Eerste stap met snijdende compound voor diepere krassen",
      "Tweede stap om de polijstsporen weg te finishen",
      "Circa 70–85% van de defecten verwijderd",
      "Aanbevolen voor donkere lak, waar krassen het hardst opvallen",
    ],
  },
  {
    id: "exterieur-3-staps",
    slug: "exterieur-3-staps-lakcorrectie",
    name: "Exterieur + 3-staps lakcorrectie",
    group: "correctie",
    priceExcl: 450,
    duration: "10 uur",
    summary:
      "De maximale correctie die zonder coating haalbaar is. Showroomniveau.",
    includes: [
      "Volledige wasbeurt en chemische decontaminatie vooraf",
      "Drie polijststappen: snijden, verfijnen en finishen",
      "Circa 85–95% van de defecten verwijderd",
      "Voor liefhebbers, klassiekers en auto's die op de foto moeten",
      "Laklaagdikte gecontroleerd voor de zekerheid",
    ],
  },
  {
    id: "compleet-1-staps",
    slug: "compleet-1-staps-lakcorrectie",
    name: "Interieur & exterieur + 1-staps lakcorrectie",
    group: "correctie",
    priceExcl: 315,
    duration: "7 uur",
    summary: "De complete beurt, met één polijststap voor de lak.",
    includes: [
      "Alles uit Interieur & exterieur compleet",
      "Lak machinaal gepolijst in één stap",
      "Circa 50–70% van de fijne krassen en swirls verdwenen",
      "Binnen en buiten in één afspraak geregeld",
    ],
  },
  {
    id: "compleet-2-staps",
    slug: "compleet-2-staps-lakcorrectie",
    name: "Interieur & exterieur + 2-staps lakcorrectie",
    group: "correctie",
    priceExcl: 405,
    duration: "9 uur",
    summary: "De complete beurt met snijden en finishen op de lak.",
    includes: [
      "Alles uit Interieur & exterieur compleet",
      "Twee polijststappen: snijden en finishen",
      "Circa 70–85% van de defecten verwijderd",
      "Populair bij auto's die verkoopklaar moeten",
    ],
  },
  {
    id: "compleet-3-staps",
    slug: "compleet-3-staps-lakcorrectie",
    name: "Interieur & exterieur + 3-staps lakcorrectie",
    group: "correctie",
    priceExcl: 495,
    duration: "11 uur",
    summary: "Alles eruit gehaald wat erin zit, binnen en buiten.",
    includes: [
      "Alles uit Interieur & exterieur compleet",
      "Drie polijststappen: snijden, verfijnen en finishen",
      "Circa 85–95% van de defecten verwijderd",
      "Loopt door over twee dagen; de auto blijft zolang staan",
    ],
  },
  {
    id: "coating-2-staps",
    slug: "keramische-coating-2-staps",
    name: "Keramische coating + 2-staps lakcorrectie",
    group: "coating",
    priceExcl: 1200,
    duration: "14 uur",
    summary:
      "Lak gecorrigeerd in twee stappen en daarna verzegeld met een keramische coating.",
    includes: [
      "Volledige wasbeurt, chemische decontaminatie en klei-behandeling",
      "Twee polijststappen tot 70–85% correctie",
      "Lak ontvet en voorbereid op de coating",
      "Keramische coating aangebracht en uitgehard",
      "Onderhoudsadvies zodat de laag zo lang mogelijk meegaat",
    ],
  },
  {
    id: "coating-3-staps",
    slug: "keramische-coating-3-staps",
    name: "Keramische coating + 3-staps lakcorrectie",
    group: "coating",
    priceExcl: 1400,
    duration: "16 uur",
    summary:
      "De maximale correctie, verzegeld. Het hoogste niveau dat ik lever.",
    includes: [
      "Volledige wasbeurt, chemische decontaminatie en klei-behandeling",
      "Drie polijststappen tot 85–95% correctie",
      "Laklaagdikte gemeten en gedocumenteerd",
      "Keramische coating aangebracht en uitgehard",
      "Loopt over meerdere dagen; de auto moet daarna droog uitharden",
    ],
  },
  {
    id: "quick-garage-detail",
    slug: "quick-garage-detail",
    name: "Quick garage detail",
    group: "zakelijk",
    priceExcl: 150,
    duration: "3–4 uur",
    summary:
      "Verkoopklaar maken van voorraad. Vaste stukprijs, snelle doorlooptijd.",
    includes: [
      "Interieur volledig gereinigd, inclusief leder of stof",
      "Exterieur gewassen, ontijzerd en van bandendressing voorzien",
      "Lichte polijstbeurt om de auto strak op de foto te krijgen",
      "Afgestemd op afleverschema; meerdere auto's per dag mogelijk",
      "Op locatie bij de garage — de voorraad hoeft niet weg",
    ],
  },
];

/** Charged per hour for work that falls outside a package. */
export const hourlyRateExcl = 45;

const euro = new Intl.NumberFormat("nl-NL", {
  style: "currency",
  currency: "EUR",
  minimumFractionDigits: 2,
});

/** Whole euros, for headline "vanaf" figures where cents are noise. */
const euroRounded = new Intl.NumberFormat("nl-NL", {
  style: "currency",
  currency: "EUR",
  maximumFractionDigits: 0,
});

export function withVat(priceExcl: number): number {
  return Math.round(priceExcl * (1 + site.vatRate) * 100) / 100;
}

export function formatPrice(value: number): string {
  return euro.format(value);
}

export function formatPriceRounded(value: number): string {
  return euroRounded.format(value);
}

export function packagesInGroup(group: PackageGroup): DetailPackage[] {
  return packages.filter((item) => item.group === group);
}

export function findPackage(slug: string): DetailPackage | undefined {
  return packages.find((item) => item.slug === slug);
}

/**
 * Cheapest consumer package, used for the "vanaf" figure in the hero.
 * Derived rather than hard-coded so editing the price list can't leave a
 * stale number on the homepage.
 */
export const lowestConsumerPriceIncl = withVat(
  Math.min(
    ...packages
      .filter((item) => item.group !== "zakelijk")
      .map((item) => item.priceExcl),
  ),
);
