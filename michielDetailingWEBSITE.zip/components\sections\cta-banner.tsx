import Link from "next/link";

import { Container } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import {
  ArrowRightIcon,
  PhoneIcon,
  WhatsAppIcon,
} from "@/components/ui/icons";
import { site, telUrl, whatsappUrl } from "@/lib/site";

export function CtaBanner({
  title = "Benieuwd wat het voor jouw auto wordt?",
  body = "Stuur me merk, model en een paar foto's. Binnen een dag heb je een vaste prijs, inclusief reiskosten — en zit je nergens aan vast.",
}: {
  title?: string;
  body?: string;
}) {
  return (
    <section className="navy-section bg-surface py-18 lg:py-24">
      <Container>
        <Reveal className="flex flex-col items-start gap-8 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-[52ch]">
            <h2 className="section-title text-balance text-ink">{title}</h2>
            <p className="mt-4 text-[16px] leading-[1.7] text-ink-dim">
              {body}
            </p>
          </div>

          <div className="flex w-full shrink-0 flex-col gap-3 sm:w-auto sm:flex-row lg:flex-col xl:flex-row">
            <Link
              href="/offerte"
              className="btn inline-flex bg-accent text-[#12263f] hover:bg-accent-light"
            >
              Offerte aanvragen
              <ArrowRightIcon size={17} />
            </Link>
            <a
              href={telUrl}
              className="btn border border-border-strong text-ink hover:bg-surface-2"
            >
              <PhoneIcon size={17} />
              {site.phoneDisplay}
            </a>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn border border-border-strong text-ink hover:bg-surface-2"
            >
              <WhatsAppIcon size={17} />
              WhatsApp
            </a>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
