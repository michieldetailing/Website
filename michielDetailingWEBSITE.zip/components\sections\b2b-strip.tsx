import Link from "next/link";

import { Container } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { ArrowRightIcon, CheckIcon } from "@/components/ui/icons";
import { formatPrice, packages } from "@/lib/packages";

const points = [
  "Vaste stukprijs per auto, geen offerte per stuk nodig",
  "Op locatie bij jullie — de voorraad hoeft niet weg",
  "Meerdere auto's op één dag, afgestemd op het afleverschema",
  "Factuur met btw-specificatie, prijzen exclusief btw",
];

/**
 * Business teaser on the homepage.
 *
 * Kept short on purpose: a dealer or fleet manager who lands here needs to
 * see that B2B exists and then get to a page written for them, rather than
 * reading consumer copy about swirl marks.
 */
export function B2bStrip() {
  const quick = packages.find((item) => item.id === "quick-garage-detail")!;

  return (
    <section className="bg-brand-tint-soft py-18 lg:py-22">
      <Container>
        <Reveal className="grid items-center gap-10 lg:grid-cols-[1.2fr_1fr]">
          <div>
            <p className="eyebrow">Voor bedrijven</p>
            <h2 className="section-title mt-4 text-balance">
              Garages, autobedrijven en wagenparken
            </h2>
            <p className="mt-4 max-w-[56ch] text-[16px] leading-[1.7] text-ink-dim">
              Voorraad verkoopklaar maken of een wagenpark op niveau houden,
              zonder dat er auto&apos;s de deur uit hoeven. Ik kom naar de zaak
              en werk door.
            </p>

            <ul className="mt-7 grid gap-2.5 sm:grid-cols-2">
              {points.map((point) => (
                <li
                  key={point}
                  className="flex gap-2.5 text-[14px] leading-snug text-ink-dim"
                >
                  <CheckIcon
                    size={15}
                    className="mt-0.5 shrink-0 text-accent-light"
                  />
                  {point}
                </li>
              ))}
            </ul>

            <Link href="/zakelijk" className="btn-primary mt-8">
              Zakelijke mogelijkheden
              <ArrowRightIcon size={17} />
            </Link>
          </div>

          <div className="rounded-lg border border-border bg-surface p-7">
            <p className="text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
              Meest gevraagd zakelijk
            </p>
            <h3 className="card-title mt-3">{quick.name}</h3>
            <p className="mt-3 text-[14px] leading-relaxed text-ink-dim">
              {quick.summary}
            </p>
            <div className="mt-6 flex items-baseline gap-2 border-t border-border pt-6">
              <span className="font-heading text-[32px] leading-none font-extrabold tracking-tight text-accent-text">
                {formatPrice(quick.priceExcl)}
              </span>
              <span className="text-[13px] text-ink-faint">
                excl. btw · {quick.duration}
              </span>
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
