import Link from "next/link";

import { PhoneIcon, WhatsAppIcon, ArrowRightIcon } from "@/components/ui/icons";
import { telUrl, whatsappUrl } from "@/lib/site";

/**
 * Fixed action bar on phones.
 *
 * Most visitors arrive on a phone and the decision they make is "call, message
 * or request a quote" — so those three stay reachable without scrolling back
 * to the top. Hidden from `lg` up, where the header already carries them.
 *
 * The spacer in the layout reserves the same height so the bar never covers
 * the end of the page.
 */
export function MobileContactBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-90 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden">
      <div className="grid grid-cols-3 gap-2 p-2.5">
        <a
          href={telUrl}
          className="flex flex-col items-center justify-center gap-1 rounded-xl py-2 text-[11.5px] font-semibold text-ink"
        >
          <PhoneIcon size={19} className="text-accent-text" />
          Bellen
        </a>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center gap-1 rounded-xl py-2 text-[11.5px] font-semibold text-ink"
        >
          <WhatsAppIcon size={19} className="text-accent-text" />
          WhatsApp
        </a>
        <Link
          href="/offerte"
          className="flex flex-col items-center justify-center gap-1 rounded-xl bg-accent py-2 text-[11.5px] font-semibold text-white"
        >
          <ArrowRightIcon size={19} />
          Offerte
        </Link>
      </div>
    </div>
  );
}
