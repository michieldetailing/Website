import { NextResponse, type NextRequest } from "next/server";

import { submitQuote } from "@/lib/offerte/submit";

export const runtime = "nodejs";
/** Never cache an endpoint that sends mail. */
export const dynamic = "force-dynamic";

function clientIp(request: NextRequest): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]!.trim();
  return request.headers.get("x-real-ip") ?? "unknown";
}

export async function POST(request: NextRequest) {
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ ok: false, reason: "invalid" }, { status: 400 });
  }

  const outcome = await submitQuote(payload, { ip: clientIp(request) });

  if (outcome.ok) {
    return NextResponse.json({ ok: true });
  }

  const status =
    outcome.reason === "invalid"
      ? 400
      : outcome.reason === "rate_limited"
        ? 429
        : 500;

  return NextResponse.json(outcome, { status });
}
