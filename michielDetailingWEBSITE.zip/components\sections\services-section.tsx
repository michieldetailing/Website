import Link from "next/link";

import { Container } from "@/components/ui/container";
import { Photo } from "@/components/ui/photo";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeader } from "@/components/ui/section-header";
import { ArrowRightIcon } from "@/components/ui/icons";
import { services } from "@/lib/services";

/** The four service categories, each linking through to its own page. */
export function ServicesSection() {
  return (
    <section id="diensten" className="bg-surface py-20 lg:py-28">
      <Container>
        <SectionHeader
          eyebrow="Wat ik doe"
          title="Vier dingen, en die dan goed"
          lead="Van een frisse beurt tot een volledig gecorrigeerde en gecoate lak. Klik door voor wat er precies gebeurt en wat het kost."
        />

        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {services.map((service, index) => (
            <Reveal key={service.id} delay={index * 70}>
              <Link
                href={`/diensten/${service.slug}`}
                className="group flex h-full flex-col overflow-hidden rounded-lg border border-border bg-surface transition-colors hover:border-border-strong"
              >
                <Photo
                  shot={`${service.title}: representatieve foto van deze behandeling`}
                  ratio="16 / 10"
                  className="rounded-none border-x-0 border-t-0"
                  sizes="(max-width: 640px) 100vw, 46vw"
                />
                <div className="flex flex-1 flex-col p-6">
                  <h3 className="card-title">{service.title}</h3>
                  <p className="mt-3 flex-1 text-[14.5px] leading-relaxed text-ink-dim">
                    {service.card}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-1.5 text-[13.5px] font-semibold text-accent-text">
                    Bekijk {service.title.toLowerCase()}
                    <ArrowRightIcon
                      size={15}
                      className="transition-transform group-hover:translate-x-0.5"
                    />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
