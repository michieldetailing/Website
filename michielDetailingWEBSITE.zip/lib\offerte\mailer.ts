import { Resend } from "resend";

import { site } from "@/lib/site";

import { buildAutoReply, buildNotification } from "./templates";
import type { QuoteSubmission } from "./schema";

export interface MailResult {
  notificationId: string | null;
  autoReplyId: string | null;
}

/**
 * Address the site sends *from*. Must be on a domain verified in Resend —
 * sending as the visitor's own address would fail SPF/DKIM. The fallback is
 * Resend's shared sandbox sender, which only delivers to the account owner,
 * so CONTACT_FROM_EMAIL has to be set before go-live.
 */
const from =
  process.env.CONTACT_FROM_EMAIL ?? `${site.name} <onboarding@resend.dev>`;
const to = process.env.CONTACT_TO_EMAIL ?? site.email;

let client: Resend | null = null;

function getClient(): Resend {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    throw new Error(
      "RESEND_API_KEY is not set — the quote form cannot send mail.",
    );
  }
  client ??= new Resend(apiKey);
  return client;
}

export function isMailConfigured(): boolean {
  return Boolean(process.env.RESEND_API_KEY);
}

/**
 * Sends the notification to Michiel and the confirmation to the customer.
 *
 * The notification is the one that matters: if the auto-reply fails we log it
 * and still report success, because the enquiry did reach the inbox.
 */
export async function sendQuoteEmails(
  submission: QuoteSubmission,
): Promise<MailResult> {
  const resend = getClient();

  const notification = buildNotification(submission);
  const notificationResponse = await resend.emails.send({
    from,
    to,
    replyTo: submission.email,
    subject: notification.subject,
    html: notification.html,
    text: notification.text,
  });

  if (notificationResponse.error) {
    throw new Error(
      `Resend rejected the notification: ${notificationResponse.error.message}`,
    );
  }

  let autoReplyId: string | null = null;
  try {
    const autoReply = buildAutoReply(submission);
    const autoReplyResponse = await resend.emails.send({
      from,
      to: submission.email,
      replyTo: to,
      subject: autoReply.subject,
      html: autoReply.html,
      text: autoReply.text,
    });
    if (autoReplyResponse.error) {
      console.error("Auto-reply rejected:", autoReplyResponse.error.message);
    } else {
      autoReplyId = autoReplyResponse.data?.id ?? null;
    }
  } catch (error) {
    console.error("Auto-reply failed:", error);
  }

  return {
    notificationId: notificationResponse.data?.id ?? null,
    autoReplyId,
  };
}
