import Image from "next/image";

import { CameraIcon } from "./icons";

/**
 * A photo slot that degrades into a labelled placeholder.
 *
 * There are no photographs yet, so every image position on the site renders a
 * tinted box naming the shot that belongs there. That keeps the layout honest
 * — the spacing is the real spacing — and doubles as the shot list.
 *
 * To go live with a real photo: drop the file in /public/assets/photos and
 * pass `src`. Nothing else about the call site changes.
 */
export function Photo({
  src,
  alt,
  shot,
  ratio = "4 / 3",
  priority = false,
  className = "",
  sizes = "(max-width: 768px) 100vw, 50vw",
}: {
  /** Path under /public. Omit while the photo does not exist yet. */
  src?: string;
  /** Required once `src` is set — describes the image for screen readers. */
  alt?: string;
  /** What to photograph. Shown in the placeholder. */
  shot: string;
  ratio?: string;
  priority?: boolean;
  className?: string;
  sizes?: string;
}) {
  if (src) {
    return (
      <div
        className={`relative min-w-0 overflow-hidden rounded-card bg-surface-3 ${className}`}
        style={{ aspectRatio: ratio }}
      >
        <Image
          src={src}
          alt={alt ?? ""}
          fill
          sizes={sizes}
          priority={priority}
          className="object-cover"
        />
      </div>
    );
  }

  return (
    // `min-w-0` is load-bearing, not tidiness. An aspect-ratio box with no
    // width derives its min-content width from its content's height — the
    // placeholder caption wraps into a tall column, and 4:3 turns that height
    // back into a very wide minimum. Inside a grid, whose items default to
    // `min-width: auto`, that inflated minimum sets the column width and the
    // whole row overflows the viewport on a phone. Setting the automatic
    // minimum to zero lets the box take the column instead of defining it.
    <div
      className={`flex min-w-0 flex-col items-center justify-center gap-3 rounded-card border border-dashed border-border-strong bg-brand-tint-soft p-6 text-center ${className}`}
      style={{ aspectRatio: ratio }}
    >
      <CameraIcon size={26} className="text-accent-light" />
      <p className="max-w-[30ch] text-[13px] leading-snug font-medium text-accent-text">
        {shot}
      </p>
      <p className="text-[11px] tracking-wide text-ink-faint uppercase">
        Foto nog toe te voegen
      </p>
    </div>
  );
}

/**
 * Before/after pair. Rendered as two labelled halves rather than a drag
 * slider: a slider that reveals two placeholders would be a gimmick, and the
 * side-by-side version reads fine on a phone. Swap in a slider once real
 * photographs exist and the comparison is worth interacting with.
 */
export function BeforeAfter({
  beforeSrc,
  afterSrc,
  shot,
  caption,
}: {
  beforeSrc?: string;
  afterSrc?: string;
  shot: string;
  caption: string;
}) {
  return (
    <figure>
      <div className="grid grid-cols-2 gap-2">
        <div className="relative">
          <Photo
            src={beforeSrc}
            alt={beforeSrc ? `${caption} — voor de behandeling` : undefined}
            shot={`VOOR — ${shot}`}
            ratio="1 / 1"
            sizes="(max-width: 768px) 50vw, 25vw"
          />
          <span className="pointer-events-none absolute top-3 left-3 rounded-full bg-ink/75 px-2.5 py-1 text-[10px] font-bold tracking-[0.12em] text-white uppercase">
            Voor
          </span>
        </div>
        <div className="relative">
          <Photo
            src={afterSrc}
            alt={afterSrc ? `${caption} — na de behandeling` : undefined}
            shot={`NA — ${shot}`}
            ratio="1 / 1"
            sizes="(max-width: 768px) 50vw, 25vw"
          />
          <span className="pointer-events-none absolute top-3 left-3 rounded-full bg-accent px-2.5 py-1 text-[10px] font-bold tracking-[0.12em] text-white uppercase">
            Na
          </span>
        </div>
      </div>
      <figcaption className="mt-3 text-[13.5px] text-ink-dim">
        {caption}
      </figcaption>
    </figure>
  );
}
