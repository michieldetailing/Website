import type { ReactNode } from "react";

/** Page gutter: 1200px content column, 24/32/60px side padding. */
export function Container({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`mx-auto w-full max-w-[1200px] px-6 lg:px-8 xl:px-15 ${className}`}
    >
      {children}
    </div>
  );
}
