import { Container } from "@/components/ui/container";
import { BeforeAfter } from "@/components/ui/photo";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeader } from "@/components/ui/section-header";

/**
 * The before/after wall.
 *
 * For a detailer this is the single most persuasive thing on the site — more
 * than any copy on this page. Every slot is a placeholder until real photos
 * exist; the shot each one needs is written into the box.
 */
const comparisons = [
  {
    shot: "motorkap in de zon, swirls duidelijk zichtbaar vóór, strak spiegelbeeld ná",
    caption: "2-staps lakcorrectie op donkere lak — swirls en wasstraatkrassen weg.",
  },
  {
    shot: "bestuurdersstoel van stof met vlekken vóór, egaal ná",
    caption: "Stoffen bekleding geëxtraheerd: vlekken uit de vezel getrokken.",
  },
  {
    shot: "velg met ingebrand remstof vóór, schoon tot in de spaken ná",
    caption: "Velgen- en zuurbehandeling — ook aan de binnenzijde van de velg.",
  },
  {
    shot: "middenconsole en dashboard met aanslag vóór, mat en schoon ná",
    caption: "Interieur compleet: aanslag weg, geen vette glansmiddelen.",
  },
];

export function Gallery() {
  return (
    <section className="bg-surface-2 py-20 lg:py-28">
      <Container>
        <SectionHeader
          eyebrow="Resultaat"
          title="Voor en na"
          lead="Beoordeel het werk aan het verschil, niet aan de beloftes. Elke auto hieronder is bij de klant op locatie gedaan."
        />

        <div className="mt-12 grid gap-8 sm:grid-cols-2">
          {comparisons.map((item, index) => (
            <Reveal key={item.caption} delay={index * 70}>
              <BeforeAfter shot={item.shot} caption={item.caption} />
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
