import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";

import { CtaBanner } from "@/components/sections/cta-banner";
import { Container } from "@/components/ui/container";
import { ArrowRightIcon, CheckIcon } from "@/components/ui/icons";
import { PackageCard } from "@/components/ui/package-card";
import { PageHero } from "@/components/ui/page-hero";
import { Photo } from "@/components/ui/photo";
import { Reveal } from "@/components/ui/reveal";
import { areas } from "@/lib/areas";
import { packages } from "@/lib/packages";
import { findService, services } from "@/lib/services";
import { ServiceJsonLd } from "@/lib/structured-data";

export function generateStaticParams() {
  return services.map((service) => ({ slug: service.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const service = findService(slug);
  if (!service) return {};

  return {
    title: service.title,
    description: service.intro,
    alternates: { canonical: `/diensten/${service.slug}` },
    openGraph: {
      title: `${service.title} — Michiel Detailing`,
      description: service.intro,
      url: `/diensten/${service.slug}`,
    },
  };
}

export default async function ServicePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const service = findService(slug);
  if (!service) notFound();

  const related = service.packageIds
    .map((id) => packages.find((item) => item.id === id))
    .filter((item) => item !== undefined);

  const otherServices = services.filter((item) => item.id !== service.id);

  return (
    <>
      <ServiceJsonLd service={service} />

      <PageHero
        eyebrow="Dienst"
        title={service.title}
        breadcrumb={[
          { label: "Home", href: "/" },
          { label: "Diensten", href: "/diensten" },
        ]}
        lead={service.intro}
      />

      <section className="bg-surface py-16 lg:py-20">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[1.15fr_1fr] lg:gap-16">
            <Reveal className="prose-md">
              {service.body.map((paragraph) => (
                <p key={paragraph.slice(0, 40)}>{paragraph}</p>
              ))}
            </Reveal>

            <Reveal direction="right" className="flex flex-col gap-6">
              <Photo
                shot={`${service.title}: proces-foto, halverwege het werk`}
                ratio="4 / 3"
                sizes="(max-width: 1024px) 100vw, 42vw"
              />

              <div className="rounded-lg border border-border bg-surface-2 p-6">
                <h2 className="text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
                  Wat je krijgt
                </h2>
                <ul className="mt-4 flex flex-col gap-2.5">
                  {service.highlights.map((line) => (
                    <li
                      key={line}
                      className="flex gap-2.5 text-[14px] leading-snug text-ink-dim"
                    >
                      <CheckIcon
                        size={15}
                        className="mt-0.5 shrink-0 text-accent-light"
                      />
                      {line}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          </div>
        </Container>
      </section>

      <section className="bg-surface-2 py-16 lg:py-20">
        <Container>
          <Reveal>
            <h2 className="section-title text-balance">
              Pakketten met {service.title.toLowerCase()}
            </h2>
            <p className="mt-3 max-w-[62ch] text-[15.5px] leading-relaxed text-ink-dim">
              Grote bedragen zijn inclusief btw. Reiskosten worden apart
              berekend en staan in je offerte.
            </p>
          </Reveal>

          <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {related.map((item, index) => (
              <Reveal key={item.id} delay={Math.min(index, 4) * 60}>
                <PackageCard item={item} />
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-10">
            <Link
              href="/prijzen"
              className="inline-flex items-center gap-1.5 text-[14.5px] font-semibold text-accent-text hover:text-accent-light"
            >
              Bekijk alle pakketten
              <ArrowRightIcon size={16} />
            </Link>
          </Reveal>
        </Container>
      </section>

      <section className="bg-surface py-16 lg:py-20">
        <Container>
          <div className="grid gap-10 lg:grid-cols-2">
            <Reveal>
              <h2 className="card-title">Andere diensten</h2>
              <ul className="mt-5 flex flex-col gap-3">
                {otherServices.map((item) => (
                  <li key={item.id}>
                    <Link
                      href={`/diensten/${item.slug}`}
                      className="group flex items-baseline justify-between gap-4 border-b border-border pb-3 text-[15px] text-ink-dim hover:text-ink"
                    >
                      <span className="font-medium text-ink">{item.title}</span>
                      <ArrowRightIcon
                        size={15}
                        className="shrink-0 text-accent-light transition-transform group-hover:translate-x-0.5"
                      />
                    </Link>
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal direction="right">
              <h2 className="card-title">
                {service.title} in jouw plaats
              </h2>
              <p className="mt-3 text-[14.5px] leading-relaxed text-ink-dim">
                Ik werk mobiel: deze behandeling doe ik gewoon bij je op de
                oprit of parkeerplaats.
              </p>
              <ul className="mt-5 flex flex-wrap gap-2">
                {areas.map((area) => (
                  <li key={area.slug}>
                    <Link
                      href={`/werkgebied/${area.slug}`}
                      className="inline-flex rounded-full border border-border bg-surface-2 px-3.5 py-1.5 text-[13.5px] font-medium text-ink transition-colors hover:border-accent hover:text-accent-text"
                    >
                      {area.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </Container>
      </section>

      <CtaBanner
        title={`${service.title} voor jouw auto?`}
        body="Stuur me merk, model en een paar foto's. Binnen een dag weet je wat het kost en hoe lang het duurt."
      />
    </>
  );
}
