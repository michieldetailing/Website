import type { Metadata } from "next";
import Link from "next/link";

import { Container } from "@/components/ui/container";
import {
  ArrowRightIcon,
  CheckIcon,
  ClockIcon,
  MailIcon,
  PhoneIcon,
} from "@/components/ui/icons";
import { PackageCard } from "@/components/ui/package-card";
import { PageHero } from "@/components/ui/page-hero";
import { Reveal } from "@/components/ui/reveal";
import { areas } from "@/lib/areas";
import {
  formatPrice,
  hourlyRateExcl,
  packages,
  withVat,
} from "@/lib/packages";
import { mailtoUrl, site, telUrl } from "@/lib/site";
import { BreadcrumbJsonLd } from "@/lib/structured-data";

export const metadata: Metadata = {
  title: "Zakelijk & wagenpark",
  description:
    "Auto detailing voor garages, autobedrijven en wagenparken in de regio Breda en Goes. Vaste stukprijs, op locatie, factuur met btw-specificatie.",
  alternates: { canonical: "/zakelijk" },
};

const audiences = [
  {
    title: "Garages en autobedrijven",
    body: "Voorraad verkoopklaar maken zonder dat er auto's de deur uit hoeven. Ik kom naar de zaak en doe meerdere auto's op een dag, afgestemd op jullie afleverschema.",
    points: [
      "Vaste stukprijs, geen offerte per auto",
      "Werk op jullie terrein",
      "Auto's fotoklaar voor de advertentie",
    ],
  },
  {
    title: "Wagenparken",
    body: "Bedrijfsauto's die er representatief uit moeten blijven zien. Periodiek terugkerende beurten zijn goedkoper per auto en houden de restwaarde op peil.",
    points: [
      "Periodieke afspraak, vaste dag",
      "Volumeafspraak bij meerdere auto's",
      "Eén factuur per periode",
    ],
  },
  {
    title: "Lease-inname en verkoop",
    body: "Een auto die schoon en gecorrigeerd wordt ingeleverd of aangeboden, levert aantoonbaar meer op dan dezelfde auto met een vuil interieur en swirls in de lak.",
    points: [
      "Interieur op inleverniveau",
      "Lakcorrectie waar het loont",
      "Snelle doorlooptijd",
    ],
  },
];

export default function BusinessPage() {
  const quick = packages.find((item) => item.id === "quick-garage-detail")!;
  // Businesses can book anything on the list; these are the ones that actually
  // get ordered in volume.
  const alsoAvailable = [
    "interieur-compleet",
    "exterieur-compleet",
    "interieur-exterieur",
    "exterieur-1-staps",
  ]
    .map((id) => packages.find((item) => item.id === id))
    .filter((item) => item !== undefined);

  return (
    <>
      <BreadcrumbJsonLd
        trail={[
          { name: "Home", path: "" },
          { name: "Zakelijk", path: "/zakelijk" },
        ]}
      />

      <PageHero
        eyebrow="Zakelijk"
        title="Voor garages, autobedrijven en wagenparken"
        breadcrumb={[{ label: "Home", href: "/" }]}
        lead="Ik kom naar jullie toe en werk door. Vaste stukprijzen, geen gedoe met offertes per auto, en een factuur met btw-specificatie. Alle bedragen op deze pagina zijn exclusief btw."
      >
        <div className="flex flex-wrap gap-3">
          <Link href="/offerte?type=zakelijk" className="btn-primary">
            Zakelijke aanvraag
            <ArrowRightIcon size={17} />
          </Link>
          <a href={telUrl} className="btn-secondary">
            <PhoneIcon size={17} />
            {site.phoneDisplay}
          </a>
        </div>
      </PageHero>

      {/* ── Headline package ── */}
      <section className="bg-surface py-16 lg:py-20">
        <Container>
          <div className="grid items-center gap-10 rounded-lg border border-accent bg-surface-2 p-8 lg:grid-cols-[1.3fr_1fr] lg:gap-14 lg:p-10">
            <Reveal>
              <p className="eyebrow">Het zakelijke pakket</p>
              <h2 className="section-title mt-3 text-balance">{quick.name}</h2>
              <p className="mt-4 max-w-[54ch] text-[16px] leading-[1.7] text-ink-dim">
                {quick.summary}
              </p>

              <ul className="mt-7 grid gap-2.5 sm:grid-cols-2">
                {quick.includes.map((line) => (
                  <li
                    key={line}
                    className="flex gap-2.5 text-[14px] leading-snug text-ink-dim"
                  >
                    <CheckIcon
                      size={15}
                      className="mt-0.5 shrink-0 text-accent-light"
                    />
                    {line}
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal direction="right">
              <div className="rounded-lg border border-border bg-surface p-7">
                <div className="flex items-baseline gap-2">
                  <span className="font-heading text-[40px] leading-none font-extrabold tracking-tight text-accent-text">
                    {formatPrice(quick.priceExcl)}
                  </span>
                  <span className="text-[13px] text-ink-faint">excl. btw</span>
                </div>
                <p className="mt-2 text-[13px] text-ink-faint">
                  {formatPrice(withVat(quick.priceExcl))} incl. btw · per auto
                </p>
                <p className="mt-4 flex items-center gap-1.5 border-t border-border pt-4 text-[13.5px] text-ink-dim">
                  <ClockIcon size={15} className="text-accent-light" />
                  {quick.duration} per auto
                </p>
                <Link
                  href="/offerte?type=zakelijk"
                  className="btn-primary mt-6 w-full"
                >
                  Plan een kennismaking
                </Link>
                <p className="mt-3 text-center text-[12.5px] text-ink-faint">
                  Bij meerdere auto&apos;s maken we een vaste afspraak
                </p>
              </div>
            </Reveal>
          </div>
        </Container>
      </section>

      {/* ── Who it's for ── */}
      <section className="bg-surface-2 py-16 lg:py-20">
        <Container>
          <Reveal>
            <h2 className="section-title text-balance">Waar het over gaat</h2>
            <p className="mt-3 max-w-[62ch] text-[15.5px] leading-relaxed text-ink-dim">
              Drie situaties waarin ik het vaakst zakelijk werk.
            </p>
          </Reveal>

          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {audiences.map((item, index) => (
              <Reveal key={item.title} delay={index * 70}>
                <div className="flex h-full flex-col rounded-lg border border-border bg-surface p-7">
                  <h3 className="card-title text-balance">{item.title}</h3>
                  <p className="mt-3 flex-1 text-[14.5px] leading-relaxed text-ink-dim">
                    {item.body}
                  </p>
                  <ul className="mt-6 flex flex-col gap-2.5 border-t border-border pt-6">
                    {item.points.map((point) => (
                      <li
                        key={point}
                        className="flex gap-2.5 text-[13.5px] leading-snug text-ink-dim"
                      >
                        <CheckIcon
                          size={15}
                          className="mt-0.5 shrink-0 text-accent-light"
                        />
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      {/* ── Other packages, ex VAT ── */}
      <section className="bg-surface py-16 lg:py-20">
        <Container>
          <Reveal>
            <h2 className="section-title text-balance">
              Ook zakelijk af te nemen
            </h2>
            <p className="mt-3 max-w-[62ch] text-[15.5px] leading-relaxed text-ink-dim">
              Het hele aanbod staat ook zakelijk open — deze vier worden het
              meest gevraagd. Grote bedragen zijn hier exclusief btw. Los werk
              buiten een pakket reken ik per uur:{" "}
              <strong className="font-semibold text-ink">
                {formatPrice(hourlyRateExcl)} excl. btw
              </strong>
              .
            </p>
          </Reveal>

          <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {alsoAvailable.map((item, index) => (
              <Reveal key={item.id} delay={index * 60}>
                <PackageCard item={item} audience="business" compact />
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-10">
            <Link
              href="/prijzen"
              className="inline-flex items-center gap-1.5 text-[14.5px] font-semibold text-accent-text hover:text-accent-light"
            >
              Alle {packages.length} pakketten bekijken
              <ArrowRightIcon size={16} />
            </Link>
          </Reveal>
        </Container>
      </section>

      {/* ── Practical ── */}
      <section className="bg-brand-tint-soft py-16 lg:py-20">
        <Container>
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
            <Reveal>
              <h2 className="section-title text-balance">Hoe we het regelen</h2>
              <div className="prose-md mt-5">
                <p>
                  <strong>Kennismaking.</strong> Bel of mail me met wat jullie
                  nodig hebben: hoeveel auto&apos;s, welk niveau, hoe vaak. Ik
                  kom langs om te kijken hoe het bij jullie werkt.
                </p>
                <p>
                  <strong>Vaste prijs.</strong> Daarna leg ik een stukprijs vast
                  die voor alle auto&apos;s geldt, zodat er niet per auto
                  onderhandeld hoeft te worden. Bij volume of een vaste frequentie
                  praten we over de prijs.
                </p>
                <p>
                  <strong>Facturatie.</strong> Eén factuur per periode of per
                  batch, met btw-specificatie, KvK ({site.kvk}) en btw-nummer (
                  {site.vat}). Betaling per bankoverschrijving.
                </p>
                <p>
                  <strong>Werkgebied.</strong> Regio Breda en regio Goes, tot{" "}
                  {site.maxTravelKm} km. Zit je daarbuiten maar gaat het om
                  volume? Bel me even, dan kijken we of het uitkomt.
                </p>
              </div>
            </Reveal>

            <Reveal direction="right">
              <div className="rounded-lg border border-border bg-surface p-7 lg:p-8">
                <h2 className="card-title">Direct contact</h2>
                <p className="mt-3 text-[14.5px] leading-relaxed text-ink-dim">
                  Voor zakelijke aanvragen bel je me het snelst. Mailen kan ook
                  — vermeld dan het aantal auto&apos;s en de gewenste frequentie.
                </p>

                <div className="mt-6 flex flex-col gap-3">
                  <a href={telUrl} className="btn-primary w-full">
                    <PhoneIcon size={17} />
                    {site.phoneDisplay}
                  </a>
                  <a href={mailtoUrl} className="btn-secondary w-full">
                    <MailIcon size={17} />
                    Mail me
                  </a>
                  <Link
                    href="/offerte?type=zakelijk"
                    className="btn-secondary w-full"
                  >
                    Aanvraagformulier
                  </Link>
                </div>

                <div className="mt-7 border-t border-border pt-6">
                  <h3 className="text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
                    Werkgebied
                  </h3>
                  <p className="mt-3 text-[13.5px] leading-relaxed text-ink-dim">
                    {areas.map((area) => area.name).join(" · ")}
                  </p>
                </div>
              </div>
            </Reveal>
          </div>
        </Container>
      </section>
    </>
  );
}
