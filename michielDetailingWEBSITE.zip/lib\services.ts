/**
 * Service categories.
 *
 * These sit one level above the price list: a visitor searching for "auto
 * polijsten Breda" lands on a category page, reads what the work involves,
 * and is then shown the packages that deliver it. Each category owns a URL,
 * which is what makes the site rank for anything other than the brand name.
 */

export interface Service {
  id: string;
  slug: string;
  /** Short label for nav and cards. */
  title: string;
  /** One line, used on the homepage cards. */
  card: string;
  /** Meta description and page intro. */
  intro: string;
  /** Body copy, one string per paragraph. */
  body: string[];
  /** Bullet list of what the visitor gets. */
  highlights: string[];
  /** Package ids from lib/packages.ts, in the order they should be shown. */
  packageIds: string[];
}

export const services: Service[] = [
  {
    id: "interieur",
    slug: "interieurreiniging",
    title: "Interieurreiniging",
    card: "Van dashboard tot kofferbak, inclusief leder en ruiten aan de binnenzijde.",
    intro:
      "Een interieurreiniging waarbij het vuil er echt uit gaat: uitzuigen tot in de naden, alle kunststof en bekleding gereinigd, en leder gevoed in plaats van ingesmeerd.",
    body: [
      "Het interieur is waar je elke dag zit, en tegelijk het onderdeel dat het snelst wordt afgeraffeld. Bij een wasstraat gaat er een stofzuiger over de vloermat en is het klaar. Ik haal de matten eruit, zuig de rails en naden uit, en pak elk paneel apart aan.",
      "Kunststof en bekleding worden gereinigd met een verdunde allesreiniger op de juiste sterkte — sterk genoeg voor de aanslag op de middenconsole, mild genoeg om de mattering van je dashboard niet aan te tasten. Glimmende dressings gebruik ik niet: een dashboard hoort er strak uit te zien, niet nat.",
      "Leder wordt met een pH-neutrale reiniger uit de nerf geborsteld en daarna gevoed, zodat het weer soepel aanvoelt en beschermd is tegen uitdrogen. Zit er een hardnekkige vlek in stoffen bekleding, dan komt de extractor erbij: die trekt het vuil met vocht uit de vezel in plaats van het dieper in te wrijven.",
    ],
    highlights: [
      "Uitzuigen tot in de rails, naden en kofferbak",
      "Dashboard, console, panelen en knoppen ontvet",
      "Leder gereinigd en gevoed, stof gereinigd of geëxtraheerd",
      "Ruiten binnenzijde streeploos",
      "Geen vette glansmiddelen — matte, schone afwerking",
    ],
    packageIds: [
      "interieur-compleet",
      "lederbehandeling",
      "stoelen-extraheren",
      "interieur-exterieur",
    ],
  },
  {
    id: "exterieur",
    slug: "handwas-en-exterieur",
    title: "Handwas & exterieur",
    card: "Krasvrij wassen volgens de twee-emmermethode, met velgen en ontijzering.",
    intro:
      "Een wasbeurt die de lak niet beschadigt: voorwas met schuim, handwas met twee emmers, velgen apart, en drogen zonder krassen.",
    body: [
      "De meeste krassen in een lak komen niet van takken of winkelwagens, maar van wassen. Een wasstraat sleept borstels met het vuil van de vorige auto over jouw lak, en één emmer sop betekent dat je hetzelfde zand telkens teruglegt. Dat is precies het spinnenwebpatroon dat je in de zon ziet.",
      "Ik begin daarom met een laag sneeuwschuim die het losse vuil laat weken en afvoert voordat er iets de lak raakt. Daarna handwas volgens de twee-emmermethode: één emmer met sop, één om de wash mitt in uit te spoelen, allebei met een grit guard op de bodem. Velgen en wielkasten gaan eerst en apart, met eigen borstels en emmer.",
      "Vliegroest en industriële neerslag laten zich niet wegwassen. Die worden chemisch losgemaakt, zodat de lak daarna echt glad aanvoelt in plaats van korrelig. Afdrogen gebeurt met een droogdoek en perslucht in de kieren, zodat er geen water uit de spiegels en grille naloopt.",
    ],
    highlights: [
      "Voorwas met sneeuwschuim, daarna handwas met twee emmers",
      "Velgen, wielkasten en banden eerst en apart",
      "Vliegroest en aanslag chemisch verwijderd",
      "Streeploos gedroogd, kieren uitgeblazen",
      "Banden en kunststof afgewerkt met dressing",
    ],
    packageIds: [
      "exterieur-compleet",
      "velgen-zuurbehandeling",
      "interieur-exterieur",
    ],
  },
  {
    id: "lakcorrectie",
    slug: "lakcorrectie-en-polijsten",
    title: "Lakcorrectie & polijsten",
    card: "Machinaal polijsten dat krassen en swirls echt wegneemt, in 1, 2 of 3 stappen.",
    intro:
      "Machinale lakcorrectie in één, twee of drie stappen. Krassen en swirls worden weggenomen, niet weggepoetst met vulmiddel dat er bij de eerste wasbeurt weer uit loopt.",
    body: [
      "Polijsten betekent dat er een flinterdunne laag van de lak wordt afgenomen tot de bodem van de kras is bereikt. Wat overblijft is een vlak oppervlak dat het licht weer als één geheel weerkaatst — dat is waarom een gecorrigeerde lak dieper en scherper oogt, en niet alleen glanzender.",
      "Het aantal stappen bepaalt hoe ver ik ga. Eén stap haalt de meeste fijne swirls eruit en levert een duidelijk verschil op voor een redelijke prijs. Twee stappen betekent eerst snijden met een agressievere combinatie en daarna finishen om de polijstsporen weg te halen; dat is wat donkere lak nodig heeft, omdat daar elke kras zichtbaar is. Drie stappen is de maximale correctie, voor liefhebbersauto's en klassiekers.",
      "Lak is eindig: je kunt hem niet oneindig vaak corrigeren. Daarom meet ik bij de zwaardere pakketten de laklaagdikte voordat ik begin, en stop ik waar dat nodig is. Liever een auto op 85% correctie met gezonde lak dan op 95% met een doorgepolijste rand.",
    ],
    highlights: [
      "1-staps: circa 50–70% van de defecten weg",
      "2-staps: circa 70–85%, aanbevolen voor donkere lak",
      "3-staps: circa 85–95%, showroomniveau",
      "Laklaagdikte gecontroleerd bij de zwaardere pakketten",
      "Geen vulmiddelen die de krassen tijdelijk verbergen",
    ],
    packageIds: [
      "exterieur-1-staps",
      "exterieur-2-staps",
      "exterieur-3-staps",
      "compleet-1-staps",
      "compleet-2-staps",
      "compleet-3-staps",
    ],
  },
  {
    id: "coating",
    slug: "keramische-coating",
    title: "Keramische coating",
    card: "Een harde beschermlaag op gecorrigeerde lak, jarenlang makkelijker wassen.",
    intro:
      "Een keramische coating op een vooraf gecorrigeerde lak: waterafstotend, bestand tegen vuil en uv, en jarenlang aanzienlijk makkelijker schoon te houden.",
    body: [
      "Een coating is geen was die je er even overheen legt. Het is een vloeibare laag die chemisch hecht aan de lak en uithardt tot een harde, gladde film. Water parelt eraf, vuil krijgt minder grip, en vogelpoep en insecten bijten zich niet meteen in de lak.",
      "Daarom gaat er altijd volledige lakcorrectie aan vooraf. Wat je onder de coating opsluit zit er de komende jaren onder: krassen die je niet eerst wegneemt, zie je straks door een glasheldere laag heen. Om dezelfde reden is coating op een verwaarloosde lak zonde van je geld.",
      "Na het aanbrengen moet de coating uitharden. De auto mag de eerste dagen niet nat worden en de eerste week niet gewassen. Daarna houd je hem bij met een pH-neutrale shampoo en zonder wasstraat — dat is het hele onderhoud. Hoe lang een coating meegaat hangt af van hoe de auto staat en hoe hij wordt gewassen; met normaal gebruik en correct onderhoud praat je over meerdere jaren.",
      "Ik geef geen garantietermijn op een coating. Ik vertel je liever vooraf eerlijk wat je kunt verwachten en waar het van afhangt, dan dat ik een getal beloof waar de praktijk zich niet aan houdt.",
    ],
    highlights: [
      "Altijd voorafgegaan door volledige lakcorrectie",
      "Sterk waterafstotend, minder aanhechting van vuil",
      "Bescherming tegen uv, insecten en vogelpoep",
      "Wassen wordt jarenlang aanzienlijk makkelijker",
      "Inclusief onderhoudsadvies voor daarna",
    ],
    packageIds: ["coating-2-staps", "coating-3-staps"],
  },
];

export const serviceIds = services.map((service) => service.id);

export function findService(slug: string): Service | undefined {
  return services.find((service) => service.slug === slug);
}
