/**
 * The primary navigation, in its own module rather than inside the nav
 * component — the nav is a client component, and server components (the 404
 * page, the sitemap) need this list without dragging the client bundle along.
 */
export const navLinks = [
  { href: "/diensten", label: "Diensten" },
  { href: "/prijzen", label: "Prijzen" },
  { href: "/werkgebied", label: "Werkgebied" },
  { href: "/zakelijk", label: "Zakelijk" },
  { href: "/over-mij", label: "Over mij" },
] as const;

/** Nav plus the pages that are reachable but not in the menu. */
export const navLinksFallback = [
  { href: "/", label: "Home" },
  ...navLinks,
  { href: "/offerte", label: "Offerte aanvragen" },
] as const;
