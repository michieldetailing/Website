import { AboutTeaser } from "@/components/sections/about-teaser";
import { AreaSection } from "@/components/sections/area-section";
import { B2bStrip } from "@/components/sections/b2b-strip";
import { Brands } from "@/components/sections/brands";
import { CtaBanner } from "@/components/sections/cta-banner";
import { FaqSection } from "@/components/sections/faq-section";
import { Gallery } from "@/components/sections/gallery";
import { Hero } from "@/components/sections/hero";
import { HowItWorks } from "@/components/sections/how-it-works";
import { PricingPreview } from "@/components/sections/pricing-preview";
import { ServicesSection } from "@/components/sections/services-section";
import { faq } from "@/lib/faq";
import { FaqJsonLd } from "@/lib/structured-data";

/**
 * Homepage order follows the decision a visitor actually makes: what is this,
 * can he do what I need, what does it cost, is the work any good, does he come
 * to me, who is he, and only then the objections.
 */
export default function HomePage() {
  // The first six answers cover what a visitor wonders before contacting;
  // the rest live on their own pages.
  const homeFaq = faq.slice(0, 6);

  return (
    <>
      <FaqJsonLd items={homeFaq} />

      <Hero />
      <Brands />
      <ServicesSection />
      <PricingPreview />
      <Gallery />
      <HowItWorks />
      <AreaSection />
      <B2bStrip />
      <AboutTeaser />
      <FaqSection
        items={homeFaq}
        lead="De vragen die ik het vaakst krijg. Staat die van jou er niet bij, bel of app me gerust."
      />
      <CtaBanner />
    </>
  );
}
