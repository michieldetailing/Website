/**
 * Service area.
 *
 * Michiel works mobile from two bases, Breda and Goes, roughly 70 km apart.
 * Each town gets its own page — that is the only realistic way to rank for
 * "auto detailing <plaats>", because a single page cannot compete for twelve
 * different towns at once.
 *
 * The `intro` on each entry is deliberately written per town rather than
 * generated from a template. Twelve pages that differ only in a place name
 * are thin content, and Google treats them as such.
 */

export const regions = ["breda", "goes"] as const;
export type Region = (typeof regions)[number];

export const regionLabels: Record<Region, { name: string; province: string }> = {
  breda: { name: "Regio Breda", province: "Noord-Brabant" },
  goes: { name: "Regio Goes", province: "Zeeland" },
};

export interface Area {
  slug: string;
  /** Town name, as it should appear in running text. */
  name: string;
  region: Region;
  province: string;
  /** Approximate road distance from the nearest base, in kilometres. */
  distanceKm: number;
  /** Whether this town is one of the two bases. */
  isBase?: boolean;
  /**
   * Town centre, set on the two bases only. Used to emit a GeoCircle in the
   * structured data so Google knows which area is actually served — a mobile
   * business has no address to key off.
   */
  coordinates?: { lat: number; lng: number };
  /** Two or three sentences of copy unique to this town. */
  intro: string;
  /** Neighbouring places named on the page, for internal linking. */
  nearby: string[];
}

export const areas: Area[] = [
  {
    slug: "breda",
    name: "Breda",
    region: "breda",
    province: "Noord-Brabant",
    distanceKm: 0,
    isBase: true,
    coordinates: { lat: 51.5719, lng: 4.7683 },
    intro:
      "Breda is mijn thuisbasis, dus hier ben ik het snelst en het vaakst. Van de Ginneken en Boeimeer tot Prinsenbeek en Teteringen: ik kom met de bus naar je oprit of parkeerplaats en werk de auto daar volledig af. In het centrum en de schil eromheen is parkeerruimte krap — laat het even weten waar de auto staat, dan stem ik het tijdslot daarop af.",
    nearby: ["Oosterhout", "Etten-Leur", "Tilburg"],
  },
  {
    slug: "oosterhout",
    name: "Oosterhout",
    region: "breda",
    province: "Noord-Brabant",
    distanceKm: 12,
    intro:
      "Oosterhout ligt op een kwartier van Breda, dus dit is voor mij nauwelijks een omweg. De ruimere opritten in Dorst, Den Hout en de nieuwbouwwijken werken in je voordeel: hoe meer ruimte rond de auto, hoe beter ik met de polijstmachine langs de flanken kan.",
    nearby: ["Breda", "Dongen", "Geertruidenberg"],
  },
  {
    slug: "etten-leur",
    name: "Etten-Leur",
    region: "breda",
    province: "Noord-Brabant",
    distanceKm: 12,
    intro:
      "Etten-Leur zit net als Oosterhout op een kwartier rijden. Veel woningen hier hebben een eigen oprit of een carport, en dat scheelt: uit de wind en uit de volle zon werken levert een beter polijstresultaat op dan op een open parkeerplaats.",
    nearby: ["Breda", "Roosendaal", "Zundert"],
  },
  {
    slug: "tilburg",
    name: "Tilburg",
    region: "breda",
    province: "Noord-Brabant",
    distanceKm: 25,
    intro:
      "Tilburg ligt een half uur van Breda en valt ruim binnen mijn werkgebied. In de binnenstad en rond de Spoorzone is een eigen parkeerplek zeldzaam; werkt een openbare plek niet, dan plannen we het bij je werk of bij familie met een oprit. Voor de langere pakketten heb ik een plek nodig waar de auto een dag kan blijven staan.",
    nearby: ["Breda", "Oosterhout", "Goirle"],
  },
  {
    slug: "roosendaal",
    name: "Roosendaal",
    region: "breda",
    province: "Noord-Brabant",
    distanceKm: 27,
    intro:
      "Roosendaal ligt tussen mijn twee werkgebieden in, dus ik kom hier regelmatig langs op weg naar Zeeland. Dat betekent dat ik hier vaak nog een tijdslot vrij heb op dagen die verder al vol zitten — vraag gerust naar de korte termijn.",
    nearby: ["Etten-Leur", "Bergen op Zoom", "Breda"],
  },
  {
    slug: "bergen-op-zoom",
    name: "Bergen op Zoom",
    region: "breda",
    province: "Noord-Brabant",
    distanceKm: 40,
    intro:
      "Bergen op Zoom is het scharnierpunt tussen Brabant en Zeeland en ligt vanuit beide bases op een goede rit. Auto's die hier dicht bij het water staan, krijgen meer met zoutaanslag en vliegroest te maken dan landinwaarts — de chemische decontaminatie in mijn exterieurbeurten is daar precies voor bedoeld.",
    nearby: ["Roosendaal", "Goes", "Steenbergen"],
  },
  {
    slug: "dordrecht",
    name: "Dordrecht",
    region: "breda",
    province: "Zuid-Holland",
    distanceKm: 30,
    intro:
      "Dordrecht is de noordelijke grens van mijn Brabantse werkgebied, op een half uur over de A16. In de historische binnenstad is het met een bus lastig manoeuvreren, dus daar plan ik het liefst op een parkeerterrein of bij je thuis in de buitenwijken.",
    nearby: ["Breda", "Zwijndrecht", "Papendrecht"],
  },
  {
    slug: "goes",
    name: "Goes",
    region: "goes",
    province: "Zeeland",
    distanceKm: 0,
    isBase: true,
    coordinates: { lat: 51.5044, lng: 3.8886 },
    intro:
      "Goes is mijn tweede basis en het vertrekpunt voor heel Zeeland. Vanuit hier bedien ik Walcheren, de Bevelanden, Schouwen-Duiveland en Zeeuws-Vlaanderen. Zeeuwse auto's krijgen structureel meer zout en vliegroest te verduren dan landinwaarts, en dat zie je terug in de lak — een goede decontaminatie maakt hier meer verschil dan waar dan ook.",
    nearby: ["Middelburg", "Vlissingen", "Bergen op Zoom"],
  },
  {
    slug: "middelburg",
    name: "Middelburg",
    region: "goes",
    province: "Zeeland",
    distanceKm: 22,
    intro:
      "Middelburg ligt op twintig minuten van Goes. De binnenstad met zijn smalle straten is geen plek om een auto een dag te laten staan, dus voor de langere pakketten werk ik hier meestal in de wijken eromheen of bij je op het werk.",
    nearby: ["Goes", "Vlissingen", "Veere"],
  },
  {
    slug: "vlissingen",
    name: "Vlissingen",
    region: "goes",
    province: "Zeeland",
    distanceKm: 30,
    intro:
      "Vlissingen ligt direct aan zee, en dat is aan auto's te zien. Zoute lucht en havenlucht zetten zich vast op de lak en zorgen voor vliegroest die je met wassen alleen niet weg krijgt. De velgen- en zuurbehandeling is hier vaak de zinnigste eerste stap, ook als je verder niets laat doen.",
    nearby: ["Middelburg", "Goes", "Veere"],
  },
  {
    slug: "terneuzen",
    name: "Terneuzen",
    region: "goes",
    province: "Zeeland",
    distanceKm: 40,
    intro:
      "Terneuzen bereik ik via de Westerscheldetunnel, wat de rit langer maakt dan de kilometers doen vermoeden. Ik plan hier daarom het liefst een hele dag, of meerdere auto's achter elkaar. Zit je met buren of collega's in dezelfde straat, dan is dat voor iedereen voordeliger op de reiskosten.",
    nearby: ["Goes", "Hulst", "Vlissingen"],
  },
  {
    slug: "zierikzee",
    name: "Zierikzee",
    region: "goes",
    province: "Zeeland",
    distanceKm: 33,
    intro:
      "Zierikzee en Schouwen-Duiveland liggen op een half uur van Goes over de Zeelandbrug. Veel auto's hier staan buiten en dicht bij het water; die hebben doorgaans meer aan een grondige decontaminatie en bescherming dan aan een snelle wasbeurt.",
    nearby: ["Goes", "Bruinisse", "Renesse"],
  },
];

export function findArea(slug: string): Area | undefined {
  return areas.find((area) => area.slug === slug);
}

export function areasInRegion(region: Region): Area[] {
  return areas.filter((area) => area.region === region);
}

/** The two bases, named in the hero and the footer. */
export const baseTowns = areas.filter((area) => area.isBase);
