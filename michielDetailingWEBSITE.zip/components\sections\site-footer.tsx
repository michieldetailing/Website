import Link from "next/link";

import { Container } from "@/components/ui/container";
import { Logo } from "@/components/ui/logo";
import { MailIcon, PhoneIcon, WhatsAppIcon } from "@/components/ui/icons";
import { areas, areasInRegion, regionLabels, regions } from "@/lib/areas";
import { services } from "@/lib/services";
import { mailtoUrl, site, telUrl, whatsappUrl } from "@/lib/site";

export function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer className="navy-section bg-surface text-ink">
      <Container className="py-16 lg:py-20">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_1fr_1fr_1.1fr]">
          {/* ── Identity ── */}
          <div>
            <Logo size={56} className="rounded-xl" />
            <p className="mt-5 max-w-[34ch] text-[14.5px] leading-relaxed text-ink-dim">
              Mobiele auto detailing. Ik kom naar je toe in de regio Breda en de
              regio Goes, tot {site.maxTravelKm} km van beide plaatsen.
            </p>

            <div className="mt-6 flex flex-col gap-2.5 text-[14.5px]">
              <a
                href={telUrl}
                className="flex items-center gap-2.5 text-ink hover:text-accent-text"
              >
                <PhoneIcon size={17} className="text-accent-text" />
                {site.phoneDisplay}
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-ink hover:text-accent-text"
              >
                <WhatsAppIcon size={17} className="text-accent-text" />
                WhatsApp
              </a>
              <a
                href={mailtoUrl}
                className="flex items-center gap-2.5 break-all text-ink hover:text-accent-text"
              >
                <MailIcon size={17} className="shrink-0 text-accent-text" />
                {site.email}
              </a>
            </div>
          </div>

          {/* ── Services ── */}
          <nav aria-label="Diensten">
            <h2 className="mb-4 text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
              Diensten
            </h2>
            <ul className="flex flex-col gap-2.5 text-[14px]">
              {services.map((service) => (
                <li key={service.id}>
                  <Link
                    href={`/diensten/${service.slug}`}
                    className="text-ink-dim hover:text-ink"
                  >
                    {service.title}
                  </Link>
                </li>
              ))}
              <li>
                <Link href="/prijzen" className="text-ink-dim hover:text-ink">
                  Alle prijzen
                </Link>
              </li>
              <li>
                <Link href="/zakelijk" className="text-ink-dim hover:text-ink">
                  Zakelijk &amp; wagenpark
                </Link>
              </li>
            </ul>
          </nav>

          {/* ── Service area ── */}
          <nav aria-label="Werkgebied">
            <h2 className="mb-4 text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
              Werkgebied
            </h2>
            <ul className="flex flex-col gap-2.5 text-[14px]">
              {areas.map((area) => (
                <li key={area.slug}>
                  <Link
                    href={`/werkgebied/${area.slug}`}
                    className="text-ink-dim hover:text-ink"
                  >
                    Detailing {area.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* ── Regions and legal ── */}
          <div>
            <h2 className="mb-4 text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
              Bedrijfsgegevens
            </h2>
            <dl className="flex flex-col gap-2.5 text-[14px] text-ink-dim">
              <div className="flex gap-2">
                <dt className="text-ink-faint">KvK</dt>
                <dd>{site.kvk}</dd>
              </div>
              <div className="flex gap-2">
                <dt className="text-ink-faint">Btw</dt>
                <dd className="break-all">{site.vat}</dd>
              </div>
            </dl>

            <div className="mt-6 flex flex-col gap-2 text-[14px]">
              {regions.map((region) => (
                <p key={region} className="text-ink-dim">
                  <span className="text-ink">{regionLabels[region].name}</span>
                  {" — "}
                  {areasInRegion(region).length} plaatsen
                </p>
              ))}
            </div>

            <ul className="mt-6 flex flex-col gap-2.5 text-[14px]">
              <li>
                <Link href="/offerte" className="text-ink-dim hover:text-ink">
                  Offerte aanvragen
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-ink-dim hover:text-ink">
                  Privacyverklaring
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-border pt-7 text-[13px] text-ink-faint sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {site.name}. Alle rechten voorbehouden.
          </p>
          <p>
            Prijzen voor particulieren zijn inclusief 21% btw. Reiskosten worden
            apart berekend.
          </p>
        </div>
      </Container>
    </footer>
  );
}
