import type { Metadata } from "next";

import { QuoteForm } from "@/components/sections/quote-form";
import { Container } from "@/components/ui/container";
import {
  ClockIcon,
  MailIcon,
  PhoneIcon,
  ShieldIcon,
  WhatsAppIcon,
} from "@/components/ui/icons";
import { PageHero } from "@/components/ui/page-hero";
import { Reveal } from "@/components/ui/reveal";
import { customerTypes, type CustomerType } from "@/lib/offerte/schema";
import { packages } from "@/lib/packages";
import { mailtoUrl, site, telUrl, whatsappUrl } from "@/lib/site";
import { BreadcrumbJsonLd } from "@/lib/structured-data";

export const metadata: Metadata = {
  title: "Offerte aanvragen",
  description:
    "Vraag vrijblijvend een offerte aan voor auto detailing in de regio Breda of Goes. Binnen één werkdag een vaste prijs, inclusief reiskosten.",
  alternates: { canonical: "/offerte" },
};

const reassurance = [
  {
    icon: ClockIcon,
    title: "Binnen één werkdag antwoord",
    body: "Je krijgt een vaste prijs, inclusief reiskosten naar jouw postcode.",
  },
  {
    icon: ShieldIcon,
    title: "Vrijblijvend",
    body: "Een aanvraag is geen opdracht. Past het niet, dan hoor ik dat gewoon.",
  },
  {
    icon: WhatsAppIcon,
    title: "Foto's helpen enorm",
    body: "Na je aanvraag krijg je een WhatsApp-link om foto's te sturen. Daarmee kan ik veel preciezer inschatten.",
  },
];

/**
 * Package links across the site carry `?pakket=<slug>`, and the business page
 * links with `?type=zakelijk`. Reading them here rather than in the client
 * component keeps the form out of a Suspense boundary and means the correct
 * option is already selected in the server-rendered HTML.
 */
export default async function QuotePage({
  searchParams,
}: {
  searchParams: Promise<{ pakket?: string; type?: string }>;
}) {
  const { pakket, type } = await searchParams;

  const defaultPackage =
    pakket && packages.some((item) => item.slug === pakket)
      ? pakket
      : "onbekend";

  const defaultCustomerType: CustomerType = customerTypes.includes(
    type as CustomerType,
  )
    ? (type as CustomerType)
    : "particulier";

  return (
    <>
      <BreadcrumbJsonLd
        trail={[
          { name: "Home", path: "" },
          { name: "Offerte aanvragen", path: "/offerte" },
        ]}
      />

      <PageHero
        eyebrow="Offerte"
        title="Vraag een prijs aan"
        breadcrumb={[{ label: "Home", href: "/" }]}
        lead="Vul in wat je auto nodig heeft en waar hij staat. Binnen één werkdag krijg je een vaste prijs, inclusief reiskosten — en zit je nergens aan vast."
      />

      <section className="bg-surface py-14 lg:py-20">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[1.35fr_1fr] lg:gap-16">
            <Reveal>
              <QuoteForm
                defaultPackage={defaultPackage}
                defaultCustomerType={defaultCustomerType}
              />
            </Reveal>

            <Reveal direction="right" className="flex flex-col gap-6">
              <div className="rounded-lg border border-border bg-surface-2 p-7">
                <h2 className="card-title">Wat er daarna gebeurt</h2>
                <dl className="mt-6 flex flex-col gap-6">
                  {reassurance.map(({ icon: Icon, title, body }) => (
                    <div key={title} className="flex gap-3.5">
                      <Icon
                        size={20}
                        className="mt-0.5 shrink-0 text-accent-light"
                      />
                      <div>
                        <dt className="text-[15px] font-semibold text-ink">
                          {title}
                        </dt>
                        <dd className="mt-1 text-[13.5px] leading-relaxed text-ink-dim">
                          {body}
                        </dd>
                      </div>
                    </div>
                  ))}
                </dl>
              </div>

              <div className="rounded-lg border border-border bg-surface p-7">
                <h2 className="card-title">Liever direct contact?</h2>
                <p className="mt-3 text-[14px] leading-relaxed text-ink-dim">
                  Bellen of appen mag altijd. Voor zakelijke aanvragen gaat dat
                  meestal het snelst.
                </p>
                <div className="mt-5 flex flex-col gap-3">
                  <a href={telUrl} className="btn-primary w-full">
                    <PhoneIcon size={17} />
                    {site.phoneDisplay}
                  </a>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary w-full"
                  >
                    <WhatsAppIcon size={17} />
                    WhatsApp
                  </a>
                  <a href={mailtoUrl} className="btn-secondary w-full">
                    <MailIcon size={17} />
                    Mail me
                  </a>
                </div>
              </div>

              <div className="rounded-lg border border-border bg-brand-tint-soft p-7">
                <h2 className="card-title text-[17px]">Goede foto&apos;s maken</h2>
                <ul className="mt-4 flex flex-col gap-2 text-[13.5px] leading-relaxed text-ink-dim">
                  <li>Bij daglicht, niet in de felle zon of in het donker.</li>
                  <li>
                    Sta zo dat je de weerspiegeling in de lak ziet — daarin
                    zitten de swirls.
                  </li>
                  <li>
                    Eén overzichtsfoto per zijde, plus een close-up van wat je
                    stoort.
                  </li>
                  <li>
                    Interieur: stoelen, vloer en kofferbak, zonder op te ruimen.
                  </li>
                </ul>
              </div>
            </Reveal>
          </div>
        </Container>
      </section>
    </>
  );
}
