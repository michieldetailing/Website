import type { Metadata } from "next";

import { Container } from "@/components/ui/container";
import { PageHero } from "@/components/ui/page-hero";
import { mailtoUrl, site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacyverklaring",
  description:
    "Welke gegevens Michiel Detailing verwerkt via het offerteformulier, waarom, hoe lang, en welke rechten je hebt.",
  alternates: { canonical: "/privacy" },
  robots: { index: true, follow: true },
};

/**
 * Privacy statement.
 *
 * Written to match what the site actually does — the offer form is the only
 * place data is collected, there is no analytics, no tracking cookie and no
 * third-party script. If any of that changes, this page has to change with it.
 */
export default function PrivacyPage() {
  return (
    <>
      <PageHero
        title="Privacyverklaring"
        breadcrumb={[{ label: "Home", href: "/" }]}
        lead="Wat er met je gegevens gebeurt als je het offerteformulier invult. Kort, omdat er weinig gebeurt."
      />

      <section className="bg-surface py-16 lg:py-20">
        <Container>
          <div className="prose-md max-w-[70ch]">
            <h2 className="card-title mt-0 mb-3">Wie verwerkt je gegevens</h2>
            <p>
              {site.name}, ingeschreven bij de Kamer van Koophandel onder nummer{" "}
              {site.kvk}, btw-nummer {site.vat}. Contact via{" "}
              <a
                href={mailtoUrl}
                className="font-semibold text-accent-text underline underline-offset-4"
              >
                {site.email}
              </a>{" "}
              of {site.phoneDisplay}.
            </p>

            <h2 className="card-title mt-10 mb-3">Welke gegevens</h2>
            <p>
              Alleen wat je zelf invult in het offerteformulier: je naam,
              e-mailadres, telefoonnummer, postcode of plaats, gegevens over je
              auto (merk, model, staat), het pakket waarin je interesse hebt, en
              je bericht. Meer velden staan er niet in.
            </p>
            <p>
              Bij het versturen wordt kortstondig je IP-adres verwerkt om
              spamaanvragen te kunnen beperken. Dat gebeurt in het geheugen van
              de server en wordt niet opgeslagen in een database.
            </p>

            <h2 className="card-title mt-10 mb-3">Waarvoor</h2>
            <p>
              Om je aanvraag te beantwoorden, een prijs te kunnen geven en een
              afspraak in te plannen. Daarnaast om — als het tot een opdracht
              komt — een factuur te kunnen maken. Je gegevens worden niet
              gebruikt voor reclame en niet verkocht of gedeeld met derden voor
              commerciële doeleinden.
            </p>

            <h2 className="card-title mt-10 mb-3">Grondslag</h2>
            <p>
              Het beantwoorden van je aanvraag is nodig om op jouw verzoek
              stappen te zetten voorafgaand aan een overeenkomst. Voor de
              spambeperking is de grondslag een gerechtvaardigd belang: een
              formulier dat niet beschermd is, wordt onbruikbaar.
            </p>

            <h2 className="card-title mt-10 mb-3">
              Wie je gegevens nog meer ziet
            </h2>
            <p>
              De site verstuurt e-mail via <strong>Resend</strong>, en de site
              zelf draait bij een hostingpartij. Beide verwerken je gegevens
              uitsluitend om de mail af te leveren en de site te tonen. Er staat
              geen analytics-, advertentie- of trackingscript op deze site, en er
              worden geen cookies geplaatst die jou volgen.
            </p>

            <h2 className="card-title mt-10 mb-3">Hoe lang</h2>
            <p>
              Aanvragen die niet tot een opdracht leiden, bewaar ik maximaal een
              jaar, zodat ik terug kan kijken als je later alsnog contact
              opneemt. Wordt het wel een opdracht, dan hoort de factuur bij mijn
              administratie en geldt de wettelijke bewaarplicht van zeven jaar.
            </p>

            <h2 className="card-title mt-10 mb-3">Je rechten</h2>
            <p>
              Je mag opvragen welke gegevens ik van je heb, ze laten corrigeren
              of laten verwijderen, en bezwaar maken tegen de verwerking. Een
              mail naar{" "}
              <a
                href={mailtoUrl}
                className="font-semibold text-accent-text underline underline-offset-4"
              >
                {site.email}
              </a>{" "}
              volstaat; je hoort binnen een maand van me. Kom je er met mij niet
              uit, dan kun je een klacht indienen bij de Autoriteit
              Persoonsgegevens.
            </p>
          </div>
        </Container>
      </section>
    </>
  );
}
