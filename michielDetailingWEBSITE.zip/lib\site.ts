/**
 * Single source of truth for the business details that appear in several
 * places (nav, contact block, footer, structured data, e-mails).
 */

/**
 * Absolute base URL, used for canonicals, sitemap and social images.
 *
 * Falls back to the Vercel-provided hostnames so preview and production
 * deploys emit correct absolute URLs before a custom domain is set up. Set
 * NEXT_PUBLIC_SITE_URL once the real domain is live — the fallback would
 * otherwise point canonicals at the *.vercel.app host.
 */
function resolveSiteUrl(): string {
  if (process.env.NEXT_PUBLIC_SITE_URL) return process.env.NEXT_PUBLIC_SITE_URL;

  const vercelHost =
    process.env.VERCEL_PROJECT_PRODUCTION_URL ?? process.env.VERCEL_URL;
  if (vercelHost) return `https://${vercelHost}`;

  return "https://www.michieldetailing.nl";
}

export const site = {
  name: "Michiel Detailing",
  tagline: "Mobiele auto detailing in Breda en Goes",
  url: resolveSiteUrl(),

  email: "michieldetailing@outlook.com",

  /**
   * Stored in E.164 so `tel:` links work from any country, with a separate
   * display form. The number is Belgian while the business is registered in
   * the Netherlands — that is correct, not a typo.
   */
  phone: "+32470514480",
  phoneDisplay: "+32 470 51 44 80",

  /** Same number; wa.me wants digits only, no plus. */
  whatsapp: "32470514480",

  /**
   * Mobile service — there is no address customers visit, so none is
   * published. Registration numbers are shown in the footer because a Dutch
   * webshop/service site is expected to identify the trader.
   */
  kvk: "42092583",
  vat: "NL005491482B78",

  /** Standard Dutch VAT rate. Consumer prices must be shown including it. */
  vatRate: 0.21,

  /** Years in business, shown in the hero trust bar and the about page. */
  yearsExperience: 2,

  /** Furthest the van travels from either base, in kilometres. */
  maxTravelKm: 80,

  /** Product lines used on the car — a trust signal, so kept in one place. */
  brands: [
    "Koch-Chemie",
    "Mafra",
    "Labocosmetica",
    "3D ONE",
    "Milwaukee",
  ],
} as const;

/** Prefilled WhatsApp deep link. */
export const whatsappUrl = `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(
  "Hoi Michiel, ik heb een vraag over detailing voor mijn auto.",
)}`;

export const telUrl = `tel:${site.phone}`;
export const mailtoUrl = `mailto:${site.email}`;
