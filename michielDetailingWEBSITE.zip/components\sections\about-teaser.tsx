import Link from "next/link";

import { Container } from "@/components/ui/container";
import { Photo } from "@/components/ui/photo";
import { Reveal } from "@/components/ui/reveal";
import { ArrowRightIcon } from "@/components/ui/icons";
import { site } from "@/lib/site";

export function AboutTeaser() {
  return (
    <section className="bg-surface py-20 lg:py-28">
      <Container>
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <Reveal direction="left">
            <Photo
              shot="Michiel aan het werk bij een auto — herkenbaar gezicht, geen gestileerde stockfoto"
              ratio="4 / 3"
              sizes="(max-width: 1024px) 100vw, 46vw"
            />
          </Reveal>

          <Reveal direction="right">
            <p className="eyebrow">Over mij</p>
            <h2 className="section-title mt-4 text-balance">
              Michiel, en een bus vol spullen
            </h2>
            <div className="prose-md mt-5">
              <p>
                Ik ben nu {site.yearsExperience} jaar bezig met detailing en doe
                het inmiddels fulltime, vanuit Breda en vanuit Goes. Wat begon
                als eindeloos poetsen aan mijn eigen auto is uitgelopen op een
                bus die vol staat met precies het gereedschap en de producten
                die het werk vragen.
              </p>
              <p>
                Ik werk aan één auto tegelijk. Dat is trager dan een wasstraat
                en dat is het punt: krassen haal je er niet uit door harder te
                boenen, maar door de tijd te nemen en de juiste combinatie van
                pad, compound en machine te kiezen. Wat ik niet kan waarmaken,
                beloof ik ook niet.
              </p>
            </div>

            <Link
              href="/over-mij"
              className="mt-7 inline-flex items-center gap-1.5 text-[14.5px] font-semibold text-accent-text hover:text-accent-light"
            >
              Meer over hoe ik werk
              <ArrowRightIcon size={16} />
            </Link>
          </Reveal>
        </div>
      </Container>
    </section>
  );
}
