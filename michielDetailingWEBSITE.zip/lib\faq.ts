import { site } from "./site";

/**
 * Shared between the rendered accordion and the FAQPage structured data, so
 * the two can never disagree. Answers are plain strings — no markup — because
 * schema.org wants text and the accordion renders them as a paragraph.
 */
export interface FaqItem {
  question: string;
  answer: string;
}

export const faq: FaqItem[] = [
  {
    question: "Kom je echt naar mij toe?",
    answer:
      `Ja. Ik werk volledig mobiel: ik kom met de bus naar je oprit, parkeerplaats of naar je werk en doe de auto daar. Je hoeft nergens heen en je hoeft geen dag vrij te nemen. Ik werk in de regio Breda en de regio Goes, tot ${site.maxTravelKm} km van beide plaatsen.`,
  },
  {
    question: "Heb je stroom en water van mij nodig?",
    answer:
      "Voor de meeste beurten is een stopcontact prettig en water handig. Laat bij je aanvraag weten wat er beschikbaar is, dan stem ik daarop af en zeg ik vooraf of het lukt. Zo kom ik niet voor een verrassing te staan en jij ook niet.",
  },
  {
    question: "Wat kost het, en zitten de reiskosten erbij in?",
    answer:
      "De pakketprijzen op deze site zijn inclusief btw en gelden voor een normale personenauto in gebruikelijke staat. Reiskosten reken ik apart, afhankelijk van de afstand tot Breda of Goes. Bij je offerte hoor je vooraf het totaalbedrag, dus er komt achteraf niets bij.",
  },
  {
    question: "Waarom is dit duurder dan de wasstraat?",
    answer:
      "Omdat het iets anders is. Een wasstraat trekt in vijf minuten borstels over je auto die daarvoor over honderd andere auto's gingen — dat is precies waar het spinnenwebpatroon in je lak vandaan komt. Ik was met de hand volgens de twee-emmermethode, decontamineer de lak chemisch en pak elk paneel apart aan. Bij lakcorrectie haal ik krassen er daadwerkelijk uit in plaats van ze te verbergen.",
  },
  {
    question: "Hoe lang duurt het?",
    answer:
      "Een losse interieur- of exterieurbeurt duurt 1 tot 2 uur. Binnen en buiten samen 3 tot 4 uur. Met lakcorrectie loopt het op naar 6 tot 11 uur, en een keramische coating kost 14 tot 16 uur werk en loopt over meerdere dagen. Bij de aanvraag hoor je precies wat het voor jouw auto wordt.",
  },
  {
    question: "Werk je ook als het regent?",
    answer:
      "Wassen kan bij regen prima. Polijsten en coaten niet: die vragen een droge, stofvrije en enigszins beschutte plek, want vocht en stof komen anders onder de laag terecht. Heb je een garage of carport, dan kan er veel meer. Zo niet, dan plannen we het weer mee en verzet ik liever een dag dan dat ik half werk lever.",
  },
  {
    question: "Hoe lang gaat een keramische coating mee?",
    answer:
      "Dat hangt af van hoe de auto staat en hoe hij gewassen wordt. Bij normaal gebruik, handwas met een pH-neutrale shampoo en geen wasstraat praat je over meerdere jaren. Ik geef er bewust geen garantietermijn op: ik vertel je liever vooraf eerlijk waar het van afhangt dan dat ik een getal beloof waar de praktijk zich niet aan houdt. Je krijgt onderhoudsadvies mee zodat je er zo lang mogelijk plezier van hebt.",
  },
  {
    question: "Kun je alle krassen eruit halen?",
    answer:
      "Niet allemaal. Een kras die je met je nagel voelt, zit door de laklaag heen en is niet weg te polijsten. Wat wel kan: swirls, wasstraatkrassen en de meeste fijne beschadigingen. Afhankelijk van het aantal polijststappen haal ik 50 tot 95% van de defecten weg. Ik zeg vooraf wat er bij jouw auto realistisch in zit — liever dat dan een teleurstelling achteraf.",
  },
  {
    question: "Werk je ook voor bedrijven en garages?",
    answer:
      "Ja. Voor garages, autobedrijven en wagenparken heb ik de Quick garage detail met een vaste stukprijs, en ik werk op locatie zodat je voorraad niet weg hoeft. Zakelijke prijzen zijn exclusief btw en bij meerdere auto's maken we een vaste afspraak.",
  },
  {
    question: "Hoe betaal ik?",
    answer:
      "Na afloop, per bankoverschrijving of contant. Je krijgt een factuur met btw-specificatie, wat voor zakelijke klanten meteen de administratie regelt.",
  },
];
