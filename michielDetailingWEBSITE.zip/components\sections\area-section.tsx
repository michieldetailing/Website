import Link from "next/link";

import { Container } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeader } from "@/components/ui/section-header";
import { ArrowRightIcon, MapPinIcon } from "@/components/ui/icons";
import { areasInRegion, regionLabels, regions } from "@/lib/areas";
import { site } from "@/lib/site";

export function AreaSection() {
  return (
    <section id="werkgebied" className="bg-surface py-20 lg:py-28">
      <Container>
        <SectionHeader
          eyebrow="Werkgebied"
          title="Twee bases, één bus"
          lead={`Ik werk vanuit Breda en vanuit Goes en rijd tot ${site.maxTravelKm} km rond beide plaatsen. Staat jouw plaats er niet bij maar zit je binnen die afstand? Vraag het gewoon — meestal kan het.`}
        />

        <div className="mt-12 grid gap-6 lg:grid-cols-2">
          {regions.map((region, index) => (
            <Reveal key={region} delay={index * 80}>
              <div className="h-full rounded-lg border border-border bg-surface-2 p-7">
                <div className="flex items-center gap-2.5">
                  <MapPinIcon size={19} className="text-accent-light" />
                  <h3 className="card-title">{regionLabels[region].name}</h3>
                </div>
                <p className="mt-2 text-[13.5px] text-ink-faint">
                  {regionLabels[region].province} · tot {site.maxTravelKm} km
                </p>

                <ul className="mt-6 flex flex-wrap gap-2">
                  {areasInRegion(region).map((area) => (
                    <li key={area.slug}>
                      <Link
                        href={`/werkgebied/${area.slug}`}
                        className="inline-flex items-center rounded-full border border-border bg-surface px-3.5 py-1.5 text-[13.5px] font-medium text-ink transition-colors hover:border-accent hover:text-accent-text"
                      >
                        {area.name}
                        {area.isBase ? (
                          <span className="ml-1.5 text-[11px] text-accent-text">
                            basis
                          </span>
                        ) : null}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-8">
          <p className="text-[14px] text-ink-dim">
            Reiskosten reken ik apart, op basis van de afstand tot de
            dichtstbijzijnde basis. Je hoort het bedrag vooraf in je offerte.{" "}
            <Link
              href="/werkgebied"
              className="inline-flex items-center gap-1 font-semibold text-accent-text hover:text-accent-light"
            >
              Bekijk het hele werkgebied
              <ArrowRightIcon size={14} />
            </Link>
          </p>
        </Reveal>
      </Container>
    </section>
  );
}
