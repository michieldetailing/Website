import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";

import { CtaBanner } from "@/components/sections/cta-banner";
import { FaqSection } from "@/components/sections/faq-section";
import { Container } from "@/components/ui/container";
import { ArrowRightIcon, MapPinIcon, VanIcon } from "@/components/ui/icons";
import { PackageCard } from "@/components/ui/package-card";
import { PageHero } from "@/components/ui/page-hero";
import { Reveal } from "@/components/ui/reveal";
import { areas, findArea, regionLabels } from "@/lib/areas";
import { faq } from "@/lib/faq";
import { packages } from "@/lib/packages";
import { services } from "@/lib/services";
import { site } from "@/lib/site";
import { AreaJsonLd, FaqJsonLd } from "@/lib/structured-data";

export function generateStaticParams() {
  return areas.map((area) => ({ slug: area.slug }));
}

function metaDescription(name: string): string {
  return `Mobiele auto detailing in ${name}: interieurreiniging, handwas, lakcorrectie en keramische coating. Ik kom naar je toe — vraag vrijblijvend een offerte aan.`;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const area = findArea(slug);
  if (!area) return {};

  return {
    title: `Auto detailing ${area.name}`,
    description: metaDescription(area.name),
    alternates: { canonical: `/werkgebied/${area.slug}` },
    openGraph: {
      title: `Auto detailing ${area.name} — Michiel Detailing`,
      description: metaDescription(area.name),
      url: `/werkgebied/${area.slug}`,
    },
  };
}

export default async function AreaPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const area = findArea(slug);
  if (!area) notFound();

  // The three packages most people in a town actually book, rather than the
  // whole list — the full price page is one click away.
  const featured = ["interieur-compleet", "interieur-exterieur", "exterieur-2-staps"]
    .map((id) => packages.find((item) => item.id === id))
    .filter((item) => item !== undefined);

  const nearbyAreas = areas.filter(
    (other) => other.slug !== area.slug && other.region === area.region,
  );

  // Travel is the question every visitor to a town page has, so it leads.
  const areaFaq = [
    {
      question: `Reken je reiskosten naar ${area.name}?`,
      answer: area.isBase
        ? `${area.name} is een van mijn twee bases, dus de reiskosten zijn hier het laagst. Het exacte bedrag staat in je offerte, zodat je het totaal vooraf weet.`
        : `Ja. ${area.name} ligt op ongeveer ${area.distanceKm} km van mijn basis, en reiskosten reken ik apart op basis van die afstand. Je ziet het bedrag vooraf in je offerte, dus er komt achteraf niets bij.`,
    },
    ...faq.slice(0, 5),
  ];

  return (
    <>
      <AreaJsonLd
        areaName={area.name}
        slug={area.slug}
        description={metaDescription(area.name)}
      />
      <FaqJsonLd items={areaFaq} />

      <PageHero
        eyebrow={regionLabels[area.region].name}
        title={`Auto detailing ${area.name}`}
        breadcrumb={[
          { label: "Home", href: "/" },
          { label: "Werkgebied", href: "/werkgebied" },
        ]}
        lead={area.intro}
      >
        <div className="flex flex-wrap items-center gap-x-6 gap-y-3 text-[14px] font-medium text-ink">
          <span className="flex items-center gap-2">
            <MapPinIcon size={17} className="text-accent-light" />
            {area.province}
          </span>
          <span className="flex items-center gap-2">
            <VanIcon size={17} className="text-accent-light" />
            {area.isBase
              ? "Thuisbasis — snelste beschikbaarheid"
              : `± ${area.distanceKm} km van mijn basis`}
          </span>
        </div>
      </PageHero>

      <section className="bg-surface py-16 lg:py-20">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:gap-16">
            <Reveal>
              <h2 className="section-title text-balance">
                Wat ik in {area.name} doe
              </h2>
              <div className="prose-md mt-5">
                <p>
                  Alle vier de diensten zijn hier gewoon beschikbaar: van een
                  losse interieurbeurt tot volledige lakcorrectie met keramische
                  coating. Ik werk mobiel, dus het gebeurt bij jou op locatie —
                  thuis, bij je werk, of waar de auto verder ook staat.
                </p>
                <p>
                  Voor de zwaardere pakketten heb ik wel een plek nodig waar de
                  auto een dag kan blijven staan, het liefst uit de wind en uit
                  de volle zon. Een oprit, carport of garage is ideaal. Laat bij
                  je aanvraag weten hoe het bij jou zit, dan zeg ik meteen wat er
                  mogelijk is.
                </p>
              </div>

              <ul className="mt-8 flex flex-col gap-3">
                {services.map((service) => (
                  <li key={service.id}>
                    <Link
                      href={`/diensten/${service.slug}`}
                      className="group flex items-center justify-between gap-4 border-b border-border pb-3"
                    >
                      <span>
                        <span className="text-[15.5px] font-semibold text-ink">
                          {service.title}
                        </span>
                        <span className="mt-0.5 block text-[13.5px] text-ink-dim">
                          {service.card}
                        </span>
                      </span>
                      <ArrowRightIcon
                        size={16}
                        className="shrink-0 text-accent-light transition-transform group-hover:translate-x-0.5"
                      />
                    </Link>
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal direction="right">
              <div className="rounded-lg border border-border bg-surface-2 p-7">
                <h2 className="card-title">Praktisch in {area.name}</h2>
                <dl className="mt-5 flex flex-col gap-4 text-[14.5px]">
                  <div>
                    <dt className="font-semibold text-ink">Afstand</dt>
                    <dd className="mt-0.5 text-ink-dim">
                      {area.isBase
                        ? `${area.name} is mijn basis. Reiskosten zijn hier minimaal.`
                        : `Ongeveer ${area.distanceKm} km. Ruim binnen mijn straal van ${site.maxTravelKm} km.`}
                    </dd>
                  </div>
                  <div>
                    <dt className="font-semibold text-ink">Wat ik nodig heb</dt>
                    <dd className="mt-0.5 text-ink-dim">
                      Een parkeerplek waar ik rondom de auto kan lopen. Stroom is
                      prettig, water handig. Geef bij je aanvraag door wat er is.
                    </dd>
                  </div>
                  <div>
                    <dt className="font-semibold text-ink">Beschikbaarheid</dt>
                    <dd className="mt-0.5 text-ink-dim">
                      {area.isBase
                        ? "Hier heb ik het vaakst ruimte in de agenda."
                        : `Ik plan ${area.name} het liefst samen met andere afspraken in de buurt. Dat drukt de reiskosten voor iedereen.`}
                    </dd>
                  </div>
                </dl>

                <Link href="/offerte" className="btn-primary mt-7 w-full">
                  Offerte voor {area.name}
                  <ArrowRightIcon size={16} />
                </Link>
              </div>
            </Reveal>
          </div>
        </Container>
      </section>

      <section className="bg-surface-2 py-16 lg:py-20">
        <Container>
          <Reveal>
            <h2 className="section-title text-balance">
              Populair in {regionLabels[area.region].name.toLowerCase()}
            </h2>
            <p className="mt-3 max-w-[62ch] text-[15.5px] leading-relaxed text-ink-dim">
              Prijzen inclusief btw. Reiskosten naar {area.name} komen daar
              apart bij en staan in je offerte.
            </p>
          </Reveal>

          <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {featured.map((item, index) => (
              <Reveal key={item.id} delay={index * 60}>
                <PackageCard item={item} />
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-10">
            <Link
              href="/prijzen"
              className="inline-flex items-center gap-1.5 text-[14.5px] font-semibold text-accent-text hover:text-accent-light"
            >
              Alle pakketten en prijzen
              <ArrowRightIcon size={16} />
            </Link>
          </Reveal>
        </Container>
      </section>

      <FaqSection
        items={areaFaq}
        eyebrow={area.name}
        title={`Vragen over detailing in ${area.name}`}
      />

      <section className="bg-surface-2 py-14">
        <Container>
          <Reveal>
            <h2 className="text-[12px] font-bold tracking-[0.16em] text-accent-text uppercase">
              Ook in de buurt
            </h2>
            <ul className="mt-5 flex flex-wrap gap-2">
              {nearbyAreas.map((other) => (
                <li key={other.slug}>
                  <Link
                    href={`/werkgebied/${other.slug}`}
                    className="inline-flex rounded-full border border-border bg-surface px-3.5 py-1.5 text-[13.5px] font-medium text-ink transition-colors hover:border-accent hover:text-accent-text"
                  >
                    {other.name}
                  </Link>
                </li>
              ))}
            </ul>
          </Reveal>
        </Container>
      </section>

      <CtaBanner
        title={`Auto laten doen in ${area.name}?`}
        body="Stuur merk, model, je postcode en een paar foto's. Binnen een dag heb je een vaste prijs inclusief reiskosten."
      />
    </>
  );
}
