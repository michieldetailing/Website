import { z } from "zod";

import { packages } from "@/lib/packages";

/** Package slugs, plus the "not sure yet" option the dropdown offers. */
export const packageChoices = [
  ...packages.map((item) => item.slug),
  "onbekend",
] as const;

export const customerTypes = ["particulier", "zakelijk"] as const;
export type CustomerType = (typeof customerTypes)[number];

export const vehicleSizes = ["klein", "middel", "groot"] as const;
export type VehicleSize = (typeof vehicleSizes)[number];

export const paintConditions = [
  "goed",
  "lichte-swirls",
  "veel-krassen",
  "onbekend",
] as const;

export const workspaceOptions = ["garage", "oprit", "openbaar"] as const;

export const vehicleSizeLabels: Record<VehicleSize, string> = {
  klein: "Klein (bijv. Polo, Corsa, Aygo)",
  middel: "Middel (bijv. Golf, Passat, 3-serie)",
  groot: "Groot (SUV, bus, 7-zitter)",
};

export const paintConditionLabels: Record<
  (typeof paintConditions)[number],
  string
> = {
  goed: "Ziet er goed uit, alleen vuil",
  "lichte-swirls": "Fijne swirls, zichtbaar in de zon",
  "veel-krassen": "Duidelijke krassen of doffe plekken",
  onbekend: "Weet ik niet — beoordeel jij maar",
};

export const workspaceLabels: Record<
  (typeof workspaceOptions)[number],
  string
> = {
  garage: "Garage of carport (overdekt)",
  oprit: "Eigen oprit",
  openbaar: "Openbare parkeerplaats",
};

/** Bots fill every field they see; humans never see this one. */
export const HONEYPOT_FIELD = "bedrijfswebsite";

/** A submission faster than this is not a person reading a form. */
export const MIN_FILL_MS = 3_000;

const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .optional()
    .transform((value) => value ?? "");

export const quoteSchema = z.object({
  customerType: z.enum(customerTypes),

  name: z.string().trim().min(2).max(120),
  email: z.string().trim().min(1).max(160).pipe(z.email()),
  // Required, unlike a normal contact form: this business calls people back.
  phone: z.string().trim().min(6).max(40),
  company: optionalText(120),

  postcode: z.string().trim().min(4).max(12),
  city: z.string().trim().min(2).max(80),

  carMake: z.string().trim().min(1).max(60),
  carModel: z.string().trim().min(1).max(60),
  carYear: optionalText(4),
  vehicleSize: z.enum(vehicleSizes),

  packageSlug: z.enum(packageChoices),
  paintCondition: z.enum(paintConditions),
  workspace: z.enum(workspaceOptions),

  hasPower: z.coerce.boolean(),
  hasWater: z.coerce.boolean(),

  preferredDate: optionalText(80),
  message: optionalText(4000),

  /** Milliseconds since epoch when the form was rendered. */
  startedAt: z.coerce.number().int().nonnegative(),
  /**
   * Deliberately permissive: a filled honeypot must parse successfully so
   * submitQuote can drop it silently. Rejecting it here would return a 400
   * naming this field, telling a bot exactly which check caught it.
   */
  [HONEYPOT_FIELD]: optionalText(200),
});

export type QuoteInput = z.infer<typeof quoteSchema>;

/** The fields a human actually filled in, for templates and logging. */
export type QuoteSubmission = Omit<
  QuoteInput,
  "startedAt" | typeof HONEYPOT_FIELD
>;

/**
 * Strips the anti-spam fields, listing the payload explicitly rather than
 * spreading. A `...rest` would silently forward any field added to the schema
 * later — including the next spam trap — straight into the e-mail templates.
 */
export function toSubmission(input: QuoteInput): QuoteSubmission {
  return {
    customerType: input.customerType,
    name: input.name,
    email: input.email,
    phone: input.phone,
    company: input.company,
    postcode: input.postcode,
    city: input.city,
    carMake: input.carMake,
    carModel: input.carModel,
    carYear: input.carYear,
    vehicleSize: input.vehicleSize,
    packageSlug: input.packageSlug,
    paintCondition: input.paintCondition,
    workspace: input.workspace,
    hasPower: input.hasPower,
    hasWater: input.hasWater,
    preferredDate: input.preferredDate,
    message: input.message,
  };
}

/** Human-readable package name for e-mail templates. */
export function packageLabel(slug: string): string {
  if (slug === "onbekend") return "Weet ik nog niet";
  return packages.find((item) => item.slug === slug)?.name ?? slug;
}
