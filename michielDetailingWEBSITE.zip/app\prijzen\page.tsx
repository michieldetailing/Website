import type { Metadata } from "next";
import Link from "next/link";

import { CtaBanner } from "@/components/sections/cta-banner";
import { Container } from "@/components/ui/container";
import { PackageCard } from "@/components/ui/package-card";
import { PageHero } from "@/components/ui/page-hero";
import { Reveal } from "@/components/ui/reveal";
import {
  formatPrice,
  groupLabels,
  hourlyRateExcl,
  packageGroups,
  packages,
  packagesInGroup,
  withVat,
} from "@/lib/packages";
import { BreadcrumbJsonLd, PriceListJsonLd } from "@/lib/structured-data";

export const metadata: Metadata = {
  title: "Prijzen en pakketten",
  description:
    "Alle detailingpakketten met prijs en werktijd: interieur, exterieur, lakcorrectie en keramische coating. Particuliere prijzen inclusief btw, reiskosten apart.",
  alternates: { canonical: "/prijzen" },
};

/** Things that genuinely change the price, said plainly rather than hidden. */
const conditions = [
  {
    title: "Waar deze prijzen op gebaseerd zijn",
    body: "Een normale personenauto in gebruikelijke staat. Voor een grote SUV, bus of een auto die extreem vervuild is, kost hetzelfde werk simpelweg meer tijd. Dat hoor je vooraf in de offerte, niet achteraf.",
  },
  {
    title: "Reiskosten",
    body: "Worden apart berekend, op basis van de afstand tot Breda of Goes. Ik rijd tot 80 km van beide plaatsen. Het bedrag staat in je offerte, dus je weet het totaal voordat je ja zegt.",
  },
  {
    title: "Los werk",
    body: `Werk dat buiten een pakket valt reken ik per uur: ${formatPrice(
      withVat(hourlyRateExcl),
    )} incl. btw (${formatPrice(hourlyRateExcl)} excl. btw).`,
  },
  {
    title: "Meerdere dagen",
    body: "De zware pakketten kosten 11 tot 16 uur werk en lopen daarom over meerdere dagen. Een keramische coating moet daarna ook nog droog uitharden. Dat plannen we samen in.",
  },
];

export default function PricingPage() {
  // Businesses have their own page with ex-VAT pricing, so the group is left
  // out here rather than shown with a consumer price it will never be sold at.
  const consumerGroups = packageGroups.filter((group) => group !== "zakelijk");

  return (
    <>
      <PriceListJsonLd
        items={packages.filter((item) => item.group !== "zakelijk")}
      />
      <BreadcrumbJsonLd
        trail={[
          { name: "Home", path: "" },
          { name: "Prijzen", path: "/prijzen" },
        ]}
      />

      <PageHero
        eyebrow="Prijzen"
        title="Wat het kost"
        breadcrumb={[{ label: "Home", href: "/" }]}
        lead={
          <>
            <p>
              Alle {packages.length} pakketten op een rij. De grote bedragen zijn
              inclusief 21% btw — dat is wat je als particulier betaalt. Het
              bedrag eronder is exclusief btw, voor als je zakelijk rijdt.
            </p>
            <p className="mt-3">
              Werk je vanuit een bedrijf of garage? Kijk dan op de{" "}
              <Link
                href="/zakelijk"
                className="font-semibold text-accent-text underline underline-offset-4"
              >
                zakelijke pagina
              </Link>
              .
            </p>
          </>
        }
      />

      {consumerGroups.map((group, groupIndex) => {
        const items = packagesInGroup(group);

        return (
          <section
            key={group}
            className={
              groupIndex % 2 === 0
                ? "bg-surface py-16 lg:py-20"
                : "bg-surface-2 py-16 lg:py-20"
            }
          >
            <Container>
              <Reveal>
                <h2 className="section-title text-balance">
                  {groupLabels[group].title}
                </h2>
                <p className="mt-3 max-w-[62ch] text-[15.5px] leading-relaxed text-ink-dim">
                  {groupLabels[group].blurb}
                </p>
              </Reveal>

              <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                {items.map((item, index) => (
                  <Reveal key={item.id} delay={Math.min(index, 4) * 60}>
                    <PackageCard item={item} />
                  </Reveal>
                ))}
              </div>
            </Container>
          </section>
        );
      })}

      <section className="bg-brand-tint-soft py-16 lg:py-20">
        <Container>
          <Reveal>
            <h2 className="section-title text-balance">Kleine lettertjes, groot</h2>
            <p className="mt-3 max-w-[62ch] text-[15.5px] leading-relaxed text-ink-dim">
              Vier dingen die de prijs kunnen veranderen. Liever nu vermeld dan
              straks een discussie.
            </p>
          </Reveal>

          <dl className="mt-10 grid gap-8 sm:grid-cols-2">
            {conditions.map((item, index) => (
              <Reveal key={item.title} delay={index * 60}>
                <dt className="card-title">{item.title}</dt>
                <dd className="mt-2.5 text-[14.5px] leading-relaxed text-ink-dim">
                  {item.body}
                </dd>
              </Reveal>
            ))}
          </dl>
        </Container>
      </section>

      <CtaBanner
        title="Niet zeker welk pakket je nodig hebt?"
        body="Stuur me een paar foto's van je lak en interieur. Dan zeg ik welk pakket erbij past — ook als dat een goedkoper pakket is dan je zelf in gedachten had."
      />
    </>
  );
}
