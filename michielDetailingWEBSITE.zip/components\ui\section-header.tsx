import type { ReactNode } from "react";

import { Reveal } from "./reveal";

/**
 * The eyebrow / title / lead trio that opens every section, so the vertical
 * rhythm stays identical across the site.
 */
export function SectionHeader({
  eyebrow,
  title,
  lead,
  align = "left",
  as: Tag = "h2",
}: {
  eyebrow?: string;
  title: ReactNode;
  lead?: ReactNode;
  align?: "left" | "center";
  as?: "h1" | "h2";
}) {
  const centered = align === "center";

  return (
    <Reveal className={centered ? "text-center" : undefined}>
      {eyebrow ? (
        <div
          className={`mb-4 flex items-center gap-3 ${
            centered ? "justify-center" : ""
          }`}
        >
          <span className="h-px w-8 bg-accent-light" aria-hidden="true" />
          <span className="eyebrow">{eyebrow}</span>
        </div>
      ) : null}

      <Tag className="section-title text-balance">{title}</Tag>

      {lead ? (
        <p
          className={`mt-5 max-w-[62ch] text-[16.5px] leading-[1.75] text-ink-dim ${
            centered ? "mx-auto" : ""
          }`}
        >
          {lead}
        </p>
      ) : null}
    </Reveal>
  );
}
