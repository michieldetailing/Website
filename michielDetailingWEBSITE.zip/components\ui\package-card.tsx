import Link from "next/link";

import { CheckIcon, ClockIcon } from "./icons";
import { formatPrice, withVat, type DetailPackage } from "@/lib/packages";

/**
 * One package.
 *
 * `audience` decides which price leads. Consumers must be shown the
 * VAT-inclusive figure by law, businesses work in ex-VAT — so both are always
 * present and only the emphasis changes.
 */
export function PackageCard({
  item,
  audience = "consumer",
  compact = false,
}: {
  item: DetailPackage;
  audience?: "consumer" | "business";
  compact?: boolean;
}) {
  const incl = withVat(item.priceExcl);
  const consumer = audience === "consumer";

  return (
    <article className="flex h-full flex-col rounded-lg border border-border bg-surface p-6 lg:p-7">
      <h3 className="card-title text-balance">{item.name}</h3>

      <p className="mt-2.5 text-[14px] leading-relaxed text-ink-dim">
        {item.summary}
      </p>

      <div className="mt-5 flex items-baseline gap-2">
        <span className="font-heading text-[30px] leading-none font-extrabold tracking-tight text-accent-text">
          {formatPrice(consumer ? incl : item.priceExcl)}
        </span>
        <span className="text-[12.5px] text-ink-faint">
          {consumer ? "incl. btw" : "excl. btw"}
        </span>
      </div>
      <p className="mt-1.5 text-[12.5px] text-ink-faint">
        {consumer
          ? `${formatPrice(item.priceExcl)} excl. btw`
          : `${formatPrice(incl)} incl. btw`}
      </p>

      <p className="mt-3 flex items-center gap-1.5 text-[13px] text-ink-faint">
        <ClockIcon size={14} />
        {item.duration} werk
      </p>

      {compact ? null : (
        <ul className="mt-6 flex flex-1 flex-col gap-2.5 border-t border-border pt-6">
          {item.includes.map((line) => (
            <li
              key={line}
              className="flex gap-2.5 text-[13.5px] leading-snug text-ink-dim"
            >
              <CheckIcon size={15} className="mt-0.5 shrink-0 text-accent-light" />
              {line}
            </li>
          ))}
        </ul>
      )}

      <Link
        href={`/offerte?pakket=${item.slug}`}
        className="btn-secondary mt-6 w-full"
      >
        Aanvragen
      </Link>
    </article>
  );
}
