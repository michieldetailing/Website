import { Container } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeader } from "@/components/ui/section-header";
import { ChevronDownIcon } from "@/components/ui/icons";
import type { FaqItem } from "@/lib/faq";

/**
 * Accordion built on <details>/<summary>.
 *
 * No JavaScript, no state, and it works with the keyboard and with a screen
 * reader out of the box — a hand-rolled version would need ARIA wiring to get
 * back to where the browser already is. Ctrl+F also finds text inside closed
 * panels in Chrome, which matters for a page of questions.
 */
export function FaqSection({
  items,
  title = "Veelgestelde vragen",
  eyebrow = "Goed om te weten",
  lead,
}: {
  items: FaqItem[];
  title?: string;
  eyebrow?: string;
  lead?: string;
}) {
  return (
    <section id="faq" className="bg-surface py-20 lg:py-28">
      <Container>
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
          <SectionHeader eyebrow={eyebrow} title={title} lead={lead} />

          <div className="border-t border-border">
            {items.map((item, index) => (
              <Reveal key={item.question} delay={Math.min(index, 5) * 40}>
                <details className="group border-b border-border">
                  <summary className="flex cursor-pointer list-none items-start justify-between gap-6 py-5 text-[16px] font-semibold text-ink [&::-webkit-details-marker]:hidden">
                    {item.question}
                    <ChevronDownIcon
                      size={19}
                      className="mt-0.5 shrink-0 text-accent-light transition-transform duration-200 group-open:rotate-180"
                    />
                  </summary>
                  <p className="pr-10 pb-6 text-[15px] leading-[1.75] text-ink-dim">
                    {item.answer}
                  </p>
                </details>
              </Reveal>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
