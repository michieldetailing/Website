const WINDOW_MS = 10 * 60 * 1000;
const MAX_PER_WINDOW = 5;

const hits = new Map<string, number[]>();

/**
 * Best-effort per-IP throttle.
 *
 * Deliberately in-memory: on serverless this is per-instance, so a determined
 * attacker spread across instances gets more than MAX_PER_WINDOW. That is an
 * accepted trade-off for a site this size — it stops casual form spam without
 * adding a datastore. Swap the body for Upstash/Redis if abuse ever warrants
 * it; the signature won't change.
 */
export function checkRateLimit(key: string, now = Date.now()): boolean {
  const recent = (hits.get(key) ?? []).filter(
    (timestamp) => now - timestamp < WINDOW_MS,
  );

  if (recent.length >= MAX_PER_WINDOW) {
    hits.set(key, recent);
    return false;
  }

  recent.push(now);
  hits.set(key, recent);

  // Opportunistic cleanup so the map can't grow without bound.
  if (hits.size > 5_000) {
    for (const [entryKey, timestamps] of hits) {
      if (timestamps.every((timestamp) => now - timestamp >= WINDOW_MS)) {
        hits.delete(entryKey);
      }
    }
  }

  return true;
}

export const __testing = {
  reset: () => hits.clear(),
  WINDOW_MS,
  MAX_PER_WINDOW,
};
