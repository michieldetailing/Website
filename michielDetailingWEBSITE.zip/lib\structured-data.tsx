import { areas, baseTowns } from "./areas";
import {
  packages,
  withVat,
  type DetailPackage,
} from "./packages";
import { services, type Service } from "./services";
import { site } from "./site";

const BUSINESS_ID = `${site.url}/#business`;

function JsonLd({ data }: { data: unknown }) {
  return (
    <script
      type="application/ld+json"
      // Values come from our own data files, never from user input.
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

/**
 * Local-business markup for a **service-area business**.
 *
 * The deliberate omission here is `address`. Michiel works out of a van and
 * customers never visit a premises, so publishing one would be wrong — and
 * Google's own guidance is that a service-area business identifies itself
 * through `areaServed` instead. The two GeoCircles are the honest description
 * of the coverage: an 80 km radius around Breda and around Goes.
 */
export function LocalBusinessJsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": ["AutoWash", "AutomotiveBusiness"],
        "@id": BUSINESS_ID,
        name: site.name,
        description:
          "Mobiele auto detailing in de regio Breda en de regio Goes: interieurreiniging, handwas, lakcorrectie en keramische coating op locatie.",
        slogan: site.tagline,
        url: site.url,
        email: site.email,
        telephone: site.phone,
        image: `${site.url}/opengraph-image`,
        logo: `${site.url}/assets/logo-square.svg`,
        priceRange: "€€",
        currenciesAccepted: "EUR",
        paymentAccepted: "Bankoverschrijving, contant",
        vatID: site.vat,
        // KvK number. `identifier` is the correct slot for a registry id.
        identifier: {
          "@type": "PropertyValue",
          name: "KvK",
          value: site.kvk,
        },
        knowsLanguage: [{ "@type": "Language", name: "Dutch", alternateName: "nl" }],
        areaServed: [
          ...baseTowns
            .filter((town) => town.coordinates)
            .map((town) => ({
              "@type": "GeoCircle",
              name: `${site.maxTravelKm} km rond ${town.name}`,
              geoMidpoint: {
                "@type": "GeoCoordinates",
                latitude: town.coordinates!.lat,
                longitude: town.coordinates!.lng,
              },
              geoRadius: site.maxTravelKm * 1000,
            })),
          ...areas.map((area) => ({ "@type": "City", name: area.name })),
        ],
        hasOfferCatalog: {
          "@type": "OfferCatalog",
          name: "Detailingpakketten",
          itemListElement: packages.map((item, index) => ({
            "@type": "Offer",
            position: index + 1,
            // Consumers see VAT-inclusive prices, so that is what the markup
            // carries — a price in the search result that does not match the
            // page is worse than no price at all.
            price: withVat(item.priceExcl).toFixed(2),
            priceCurrency: "EUR",
            valueAddedTaxIncluded: true,
            itemOffered: {
              "@type": "Service",
              name: item.name,
              description: item.summary,
            },
          })),
        },
      },
      {
        "@type": "WebSite",
        "@id": `${site.url}/#website`,
        url: site.url,
        name: site.name,
        inLanguage: "nl-NL",
        publisher: { "@id": BUSINESS_ID },
      },
    ],
  };

  return <JsonLd data={data} />;
}

/** Per-service markup plus the breadcrumb trail back to the homepage. */
export function ServiceJsonLd({ service }: { service: Service }) {
  const url = `${site.url}/diensten/${service.slug}`;

  const data = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Service",
        "@id": `${url}#service`,
        name: service.title,
        description: service.intro,
        url,
        serviceType: service.title,
        inLanguage: "nl-NL",
        provider: { "@id": BUSINESS_ID },
        areaServed: areas.map((area) => ({ "@type": "City", name: area.name })),
      },
      breadcrumbs([
        { name: "Home", path: "" },
        { name: "Diensten", path: "/diensten" },
        { name: service.title, path: `/diensten/${service.slug}` },
      ]),
    ],
  };

  return <JsonLd data={data} />;
}

/** Markup for a single town page. */
export function AreaJsonLd({
  areaName,
  slug,
  description,
}: {
  areaName: string;
  slug: string;
  description: string;
}) {
  const url = `${site.url}/werkgebied/${slug}`;

  const data = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Service",
        "@id": `${url}#service`,
        name: `Auto detailing ${areaName}`,
        description,
        url,
        inLanguage: "nl-NL",
        provider: { "@id": BUSINESS_ID },
        areaServed: { "@type": "City", name: areaName },
      },
      breadcrumbs([
        { name: "Home", path: "" },
        { name: "Werkgebied", path: "/werkgebied" },
        { name: areaName, path: `/werkgebied/${slug}` },
      ]),
    ],
  };

  return <JsonLd data={data} />;
}

/** Price list markup, so the packages can surface as a rich result. */
export function PriceListJsonLd({ items }: { items: DetailPackage[] }) {
  const data = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Prijzen en pakketten",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      item: {
        "@type": "Service",
        name: item.name,
        description: item.summary,
        provider: { "@id": BUSINESS_ID },
        offers: {
          "@type": "Offer",
          price: withVat(item.priceExcl).toFixed(2),
          priceCurrency: "EUR",
          valueAddedTaxIncluded: true,
          availability: "https://schema.org/InStock",
        },
      },
    })),
  };

  return <JsonLd data={data} />;
}

/**
 * FAQ markup. Google only shows FAQ rich results for a narrow set of sites
 * these days, but the markup still helps it understand the page — and costs
 * nothing to emit.
 */
export function FaqJsonLd({
  items,
}: {
  items: { question: string; answer: string }[];
}) {
  const data = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: { "@type": "Answer", text: item.answer },
    })),
  };

  return <JsonLd data={data} />;
}

export function BreadcrumbJsonLd({
  trail,
}: {
  trail: { name: string; path: string }[];
}) {
  return <JsonLd data={{ "@context": "https://schema.org", ...breadcrumbs(trail) }} />;
}

function breadcrumbs(trail: { name: string; path: string }[]) {
  return {
    "@type": "BreadcrumbList",
    itemListElement: trail.map((crumb, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: crumb.name,
      item: `${site.url}${crumb.path}`,
    })),
  };
}

/** Every service, for the services index page. */
export function ServiceListJsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Diensten",
    itemListElement: services.map((service, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: service.title,
      url: `${site.url}/diensten/${service.slug}`,
    })),
  };

  return <JsonLd data={data} />;
}
