import type { MetadataRoute } from "next";

import { site } from "@/lib/site";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: site.name,
    short_name: "Michiel Detailing",
    description: site.tagline,
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#c7d5e9",
    lang: "nl-NL",
    icons: [
      {
        src: "/assets/logo-square.svg",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  };
}
