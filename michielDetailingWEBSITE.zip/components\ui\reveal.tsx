"use client";

import {
  useEffect,
  useRef,
  useState,
  type ElementType,
  type ReactNode,
} from "react";

type Direction = "up" | "left" | "right";

const directionClass: Record<Direction, string> = {
  up: "reveal-up",
  left: "reveal-from-left",
  right: "reveal-from-right",
};

interface RevealProps {
  children: ReactNode;
  /** Which way the element travels in from. */
  direction?: Direction;
  /** Stagger, in milliseconds. */
  delay?: number;
  className?: string;
  as?: ElementType;
}

/**
 * Fades and slides its children in the first time they scroll into view.
 * Reduced-motion users get the final state immediately (handled in CSS).
 */
export function Reveal({
  children,
  direction = "up",
  delay = 0,
  className = "",
  as: Tag = "div",
}: RevealProps) {
  const ref = useRef<HTMLElement>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setShown(true);
            observer.disconnect();
          }
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -60px 0px" },
    );

    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <Tag
      ref={ref}
      style={delay ? { transitionDelay: `${delay}ms` } : undefined}
      className={`reveal-hidden ${
        shown ? "reveal-shown" : directionClass[direction]
      } ${className}`}
    >
      {children}
    </Tag>
  );
}
