import Link from "next/link";

import { Container } from "@/components/ui/container";
import { ArrowRightIcon } from "@/components/ui/icons";
import { navLinksFallback } from "@/lib/nav-links";

export default function NotFound() {
  return (
    <section className="hero-bg relative overflow-hidden">
      <div className="hero-grid absolute inset-0" aria-hidden="true" />

      <Container className="relative py-24 lg:py-32">
        <p className="eyebrow">404</p>
        <h1 className="hero-title mt-4 max-w-[18ch] text-balance">
          Deze pagina bestaat niet
        </h1>
        <p className="mt-5 max-w-[52ch] text-[17px] leading-[1.7] text-ink-dim">
          Misschien is de link verouderd, of is er iets misgegaan met het
          adres. Hieronder staan de pagina&apos;s die er wel zijn.
        </p>

        <ul className="mt-9 flex flex-wrap gap-2.5">
          {navLinksFallback.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                className="inline-flex rounded-full border border-border bg-surface px-4 py-2 text-[14px] font-medium text-ink transition-colors hover:border-accent hover:text-accent-text"
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        <Link href="/offerte" className="btn-primary mt-9">
          Offerte aanvragen
          <ArrowRightIcon size={17} />
        </Link>
      </Container>
    </section>
  );
}
