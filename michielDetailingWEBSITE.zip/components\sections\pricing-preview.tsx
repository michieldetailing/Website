import Link from "next/link";

import { Container } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeader } from "@/components/ui/section-header";
import { ArrowRightIcon, CheckIcon, ClockIcon } from "@/components/ui/icons";
import { formatPrice, packages, withVat } from "@/lib/packages";

/**
 * Three packages that show the ladder: a single treatment, the full car, and
 * the full car with paint correction. The complete list lives on /prijzen —
 * seventeen packages on the homepage would stall the visitor rather than
 * help them.
 */
const featuredIds = [
  "interieur-compleet",
  "interieur-exterieur",
  "exterieur-2-staps",
] as const;

const POPULAR_ID = "interieur-exterieur";

export function PricingPreview() {
  const featured = featuredIds.map(
    (id) => packages.find((item) => item.id === id)!,
  );

  return (
    <section className="bg-surface-2 py-20 lg:py-28">
      <Container>
        <SectionHeader
          eyebrow="Prijzen"
          title="Vanaf-prijzen, vooraf duidelijk"
          lead="Deze bedragen gelden voor een normale personenauto in gebruikelijke staat. Is de auto groter of flink vervuild, dan hoor je dat in de offerte — niet achteraf op de rekening."
        />

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {featured.map((item, index) => {
            const popular = item.id === POPULAR_ID;

            return (
              <Reveal key={item.id} delay={index * 80} className="h-full">
                <div
                  className={`flex h-full flex-col rounded-lg border bg-surface p-7 ${
                    popular
                      ? "border-accent shadow-[0_2px_24px_var(--accent-glow)]"
                      : "border-border"
                  }`}
                >
                  {popular ? (
                    <span className="mb-4 self-start rounded-full bg-accent px-3 py-1 text-[10.5px] font-bold tracking-[0.12em] text-white uppercase">
                      Meest gekozen
                    </span>
                  ) : null}

                  <h3 className="card-title text-balance">{item.name}</h3>

                  <p className="mt-3 text-[14px] leading-relaxed text-ink-dim">
                    {item.summary}
                  </p>

                  <div className="mt-6 flex items-baseline gap-2">
                    <span className="font-heading text-[34px] leading-none font-extrabold tracking-tight text-accent-text">
                      {formatPrice(withVat(item.priceExcl))}
                    </span>
                    <span className="text-[13px] text-ink-faint">incl. btw</span>
                  </div>
                  <p className="mt-1.5 flex items-center gap-1.5 text-[13px] text-ink-faint">
                    <ClockIcon size={14} />
                    {item.duration} werk
                  </p>

                  <ul className="mt-6 flex flex-1 flex-col gap-2.5 border-t border-border pt-6">
                    {item.includes.slice(0, 4).map((line) => (
                      <li
                        key={line}
                        className="flex gap-2.5 text-[13.5px] leading-snug text-ink-dim"
                      >
                        <CheckIcon
                          size={15}
                          className="mt-0.5 shrink-0 text-accent-light"
                        />
                        {line}
                      </li>
                    ))}
                  </ul>

                  <Link
                    href={`/offerte?pakket=${item.slug}`}
                    className={`mt-7 w-full ${
                      popular ? "btn-primary" : "btn-secondary"
                    }`}
                  >
                    Dit pakket aanvragen
                  </Link>
                </div>
              </Reveal>
            );
          })}
        </div>

        <Reveal className="mt-10 text-center">
          <Link
            href="/prijzen"
            className="inline-flex items-center gap-1.5 text-[14.5px] font-semibold text-accent-text hover:text-accent-light"
          >
            Alle {packages.length} pakketten en het uurtarief
            <ArrowRightIcon size={16} />
          </Link>
        </Reveal>
      </Container>
    </section>
  );
}
