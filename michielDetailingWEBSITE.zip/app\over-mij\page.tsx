import type { Metadata } from "next";

import { CtaBanner } from "@/components/sections/cta-banner";
import { FaqSection } from "@/components/sections/faq-section";
import { Container } from "@/components/ui/container";
import { PageHero } from "@/components/ui/page-hero";
import { Photo } from "@/components/ui/photo";
import { Reveal } from "@/components/ui/reveal";
import { faq } from "@/lib/faq";
import { site } from "@/lib/site";
import { BreadcrumbJsonLd, FaqJsonLd } from "@/lib/structured-data";

export const metadata: Metadata = {
  title: "Over mij",
  description: `Michiel, ${site.yearsExperience} jaar auto detailing vanuit Breda en Goes. Hoe ik werk, waarmee ik werk, en wat ik wel en niet beloof.`,
  alternates: { canonical: "/over-mij" },
};

const principles = [
  {
    title: "Eén auto tegelijk",
    body: "Ik plan geen vijf auto's op een dag om er meer doorheen te jagen. Wat er gepland staat, krijgt de tijd die het nodig heeft. Duurt iets langer dan ingeschat, dan is dat mijn probleem en niet dat van jou.",
  },
  {
    title: "Vooraf eerlijk over wat kan",
    body: "Niet elke kras gaat eruit en niet elke auto heeft een coating nodig. Als een goedkoper pakket het beste resultaat geeft voor jouw auto, zeg ik dat — daar heb ik op de lange termijn meer aan dan aan één dure klus.",
  },
  {
    title: "Geen verstopte kosten",
    body: "De prijs die je in je offerte krijgt, inclusief reiskosten, is de prijs op de factuur. Blijkt de auto onderweg veel meer werk dan gedacht, dan bel ik je voordat ik doorga, niet erna.",
  },
  {
    title: "Materiaal dat past bij het werk",
    body: `Ik werk met ${site.brands.slice(0, 3).join(", ")} en ${site.brands.at(-1)}. Elk product voor het doel waarvoor het gemaakt is: een velgreiniger hoort niet op je lak, en een allesreiniger niet op je leder.`,
  },
];

export default function AboutPage() {
  const aboutFaq = faq.slice(3);

  return (
    <>
      <FaqJsonLd items={aboutFaq} />
      <BreadcrumbJsonLd
        trail={[
          { name: "Home", path: "" },
          { name: "Over mij", path: "/over-mij" },
        ]}
      />

      <PageHero
        eyebrow="Over mij"
        title="Michiel, en een bus vol spullen"
        breadcrumb={[{ label: "Home", href: "/" }]}
        lead={`${site.yearsExperience} jaar detailing, twee bases, en een sterke voorkeur voor werk waar je van dichtbij naar kunt kijken.`}
      />

      <section className="bg-surface py-16 lg:py-20">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:gap-16">
            <Reveal className="prose-md">
              <p>
                Het begon zoals het bij de meesten begint: met te veel tijd
                steken in mijn eigen auto. Eerst wassen, daarna beter wassen,
                daarna polijsten, en op een gegeven moment stond de garage vol
                met spullen en vroegen mensen om me heen of ik hun auto ook wilde
                doen. Inmiddels doe ik dit {site.yearsExperience} jaar en is het
                mijn werk.
              </p>
              <p>
                Ik werk volledig mobiel, vanuit Breda en vanuit Goes. Dat is een
                bewuste keuze: een werkplaats betekent dat jij moet brengen en
                halen en een dag zonder auto zit. Met een bus vol gereedschap kom
                ik gewoon naar je oprit, en dan hoef jij helemaal niets.
              </p>
              <p>
                Wat me aan dit vak bevalt is dat je het resultaat direct ziet. Een
                lak die vol swirls zit en na een dag werk weer als een spiegel
                reflecteert — daar is geen praatje bij nodig. Dat is ook meteen de
                reden dat ik veel foto&apos;s maak van voor en na: je hoeft me
                niet op mijn woord te geloven.
              </p>
              <p>
                Ik ben eerlijk over wat er niet kan. Een kras die je met je nagel
                voelt, zit door de laklaag heen en polijst er niet uit. Een auto
                die volledig verwaarloosd is, wordt met één beurt niet nieuw. Dat
                zeg ik liever vooraf dan dat je achteraf teleurgesteld bent.
              </p>
            </Reveal>

            <Reveal direction="right" className="flex flex-col gap-4">
              <Photo
                shot="Michiel aan het werk — portret, herkenbaar gezicht, bij de auto"
                ratio="3 / 4"
                sizes="(max-width: 1024px) 100vw, 42vw"
              />
              <div className="grid grid-cols-2 gap-4">
                <Photo
                  shot="De bus met de deuren open, apparatuur zichtbaar"
                  ratio="1 / 1"
                  sizes="(max-width: 1024px) 50vw, 21vw"
                />
                <Photo
                  shot="Werkbank of productenplank — merken herkenbaar"
                  ratio="1 / 1"
                  sizes="(max-width: 1024px) 50vw, 21vw"
                />
              </div>
            </Reveal>
          </div>
        </Container>
      </section>

      <section className="bg-surface-2 py-16 lg:py-20">
        <Container>
          <Reveal>
            <h2 className="section-title text-balance">Hoe ik werk</h2>
            <p className="mt-3 max-w-[62ch] text-[15.5px] leading-relaxed text-ink-dim">
              Vier dingen waar je me aan mag houden.
            </p>
          </Reveal>

          <dl className="mt-10 grid gap-8 sm:grid-cols-2">
            {principles.map((item, index) => (
              <Reveal key={item.title} delay={index * 60}>
                <dt className="card-title">{item.title}</dt>
                <dd className="mt-2.5 text-[14.5px] leading-relaxed text-ink-dim">
                  {item.body}
                </dd>
              </Reveal>
            ))}
          </dl>
        </Container>
      </section>

      <FaqSection
        items={aboutFaq}
        eyebrow="Vragen"
        title="Wat mensen me vragen"
      />

      <CtaBanner />
    </>
  );
}
