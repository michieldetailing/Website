# Conventies

Website voor Michiel Detailing. Next.js 16 App Router, React 19, Tailwind 4,
TypeScript strict, zod, Resend. Nederlandstalig, één taal, light-only.

## Inhoud hoort in `lib/`, niet in pagina's

`site.ts`, `packages.ts`, `services.ts`, `areas.ts`, `faq.ts` zijn de bron.
Pagina's lezen daaruit en leiden af. Geen prijs, plaatsnaam of telefoonnummer
letterlijk in een component — een wijziging moet op één plek volstaan en overal
doorslaan, inclusief de structured data.

Getallen die uit de data volgen ("alle 15 pakketten", "vanaf € 73") worden
berekend, niet ingetypt.

## Prijzen en btw

`priceExcl` is de opgeslagen waarde; `withVat()` leidt de consumentenprijs af.
Nooit beide opslaan. Particuliere pagina's tonen incl. btw met excl. eronder,
`/zakelijk` andersom (`PackageCard` heeft daarvoor `audience`).

## Kleuren

Alleen semantische tokens uit `globals.css` (`bg-surface`, `text-ink-dim`,
`border-border`…), nooit een letterlijke kleur in een component. Het logoblauw
`#c7d5e9` is een vlak, geen tekstkleur — het haalt 1,4:1 op wit. Tekst en
knoppen gebruiken `--accent` (11,5:1) en `--accent-light` (6,8:1).

Alfawaarden van `--ink-dim` en `--ink-faint` zijn op contrast gekozen (5,9:1 en
4,7:1). Niet lichter maken: beide dragen echte inhoud.

`.navy-section` herdefinieert de tokens lokaal, zodat kinderen geen
sectiespecifieke klassen nodig hebben.

## Tailwind 4

`@apply` accepteert alleen utilities, geen eigen componentklassen. `.btn-primary`
kan `.btn` dus niet hergebruiken; de gedeelde geometrie staat herhaald in
`globals.css`. Niet "opschonen" tot een compositie — dat breekt de build.

## Valkuilen die al een keer gebeten hebben

- **`min-w-0` op aspect-ratio-boxen** (`components/ui/photo.tsx`). Zonder dat
  leidt zo'n box zijn minimumbreedte af uit de hoogte van zijn inhoud, en
  bepaalt hij daarmee de breedte van de gridkolom in plaats van andersom —
  horizontale overflow op mobiel.
- **Geen `position: fixed` binnen een element met `backdrop-blur`.** Een
  backdrop-filter maakt het element containing block voor fixed kinderen. Het
  mobiele menu staat daarom náást `<header>`, niet erin.
- **Geen `setState` synchroon in een effect** en geen `Date.now()` tijdens
  render — de React-lintregels zijn hier fouten, geen waarschuwingen.

## Formulier

`quote-form.tsx` → `POST /api/offerte` → `lib/offerte/submit.ts`. De pijplijn
staat los van HTTP zodat de route dun blijft. Honeypot en te-snel-verzonden
geven bewust `ok: true` terug: een bot mag niet leren welk signaal hem ving.

`toSubmission()` somt de velden expliciet op in plaats van te spreaden, zodat
een later toegevoegd antispamveld niet vanzelf in de mail belandt.

Bewust geen foto-upload; de bevestigingsmail vraagt om foto's via WhatsApp.

## Verifiëren

`npm run typecheck` en `npm run lint` moeten allebei schoon zijn, en
`npm run build` moet slagen. Voor layoutwijzigingen ook op 375px breed
controleren op horizontale overflow.
