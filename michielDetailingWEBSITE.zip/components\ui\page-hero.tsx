import Link from "next/link";
import type { ReactNode } from "react";

import { Container } from "./container";

/**
 * Header band for every page other than the homepage: breadcrumb, title,
 * lead, optional actions. Keeping it in one component is what stops the inner
 * pages from each inventing their own top-of-page spacing.
 */
export function PageHero({
  eyebrow,
  title,
  lead,
  breadcrumb,
  children,
}: {
  eyebrow?: string;
  title: string;
  lead?: ReactNode;
  /** Trail excluding the current page, which is appended as plain text. */
  breadcrumb?: { label: string; href: string }[];
  children?: ReactNode;
}) {
  return (
    <section className="hero-bg relative overflow-hidden border-b border-border">
      <div className="hero-grid absolute inset-0" aria-hidden="true" />

      <Container className="relative py-14 lg:py-20">
        {breadcrumb?.length ? (
          <nav aria-label="Kruimelpad" className="mb-6">
            <ol className="flex flex-wrap items-center gap-1.5 text-[13px] text-ink-faint">
              {breadcrumb.map((crumb) => (
                <li key={crumb.href} className="flex items-center gap-1.5">
                  <Link href={crumb.href} className="hover:text-accent-text">
                    {crumb.label}
                  </Link>
                  <span aria-hidden="true">/</span>
                </li>
              ))}
              <li aria-current="page" className="text-ink-dim">
                {title}
              </li>
            </ol>
          </nav>
        ) : null}

        {eyebrow ? <p className="eyebrow mb-4">{eyebrow}</p> : null}

        <h1 className="hero-title max-w-[20ch] text-balance">{title}</h1>

        {lead ? (
          <div className="mt-5 max-w-[64ch] text-[17px] leading-[1.7] text-ink-dim">
            {lead}
          </div>
        ) : null}

        {children ? <div className="mt-8">{children}</div> : null}
      </Container>
    </section>
  );
}
