import Link from "next/link";

import { Container } from "@/components/ui/container";
import { Photo } from "@/components/ui/photo";
import {
  ArrowRightIcon,
  MapPinIcon,
  ShieldIcon,
  SparkleIcon,
  VanIcon,
} from "@/components/ui/icons";
import { formatPriceRounded, lowestConsumerPriceIncl } from "@/lib/packages";
import { site } from "@/lib/site";

const trustPoints = [
  { icon: VanIcon, label: "Ik kom naar je toe" },
  { icon: SparkleIcon, label: "Handwas, nooit een borstel" },
  { icon: MapPinIcon, label: `Regio Breda & Goes · tot ${site.maxTravelKm} km` },
  { icon: ShieldIcon, label: "Vooraf een vaste prijs" },
];

export function Hero() {
  return (
    <section className="hero-bg relative overflow-hidden">
      <div className="hero-grid absolute inset-0" aria-hidden="true" />

      <Container className="relative py-16 lg:py-24">
        <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_1fr] lg:gap-16">
          <div>
            <p className="eyebrow">Mobiele auto detailing</p>

            <h1 className="hero-title mt-4 text-balance">
              Je auto weer als nieuw.{" "}
              <span className="text-accent-text">Bij jou op de oprit.</span>
            </h1>

            <p className="mt-6 max-w-[54ch] text-[17px] leading-[1.7] text-ink-dim">
              Interieurreiniging, handwas, lakcorrectie en keramische coating —
              met de hand, met goede producten, en zonder dat jij ergens heen
              hoeft. Werkgebied: regio Breda en regio Goes.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              <Link href="/offerte" className="btn-primary">
                Vrijblijvend offerte aanvragen
                <ArrowRightIcon size={17} />
              </Link>
              <Link href="/prijzen" className="btn-secondary">
                Bekijk de prijzen
              </Link>
            </div>

            <p className="mt-4 text-[13.5px] text-ink-faint">
              Pakketten vanaf {formatPriceRounded(lowestConsumerPriceIncl)}{" "}
              incl. btw · reiskosten apart
            </p>

            <ul className="mt-10 grid grid-cols-2 gap-x-6 gap-y-4 border-t border-border pt-8">
              {trustPoints.map(({ icon: Icon, label }) => (
                <li
                  key={label}
                  className="flex items-start gap-2.5 text-[13.5px] leading-snug font-medium text-ink"
                >
                  <Icon size={18} className="mt-px shrink-0 text-accent-light" />
                  {label}
                </li>
              ))}
            </ul>
          </div>

          <div className="grid gap-3">
            <Photo
              shot="Hero: driekwart vooraanzicht van een net afgewerkte auto, buiten, bij zacht licht — reflecties strak en onafgebroken"
              ratio="4 / 3"
              priority
              sizes="(max-width: 1024px) 100vw, 46vw"
            />
            <div className="grid grid-cols-2 gap-3">
              <Photo
                shot="Detail: waterparels op een gecoate motorkap"
                ratio="1 / 1"
                sizes="(max-width: 1024px) 50vw, 23vw"
              />
              <Photo
                shot="Detail: polijstmachine op een paneel, halve kant gecorrigeerd"
                ratio="1 / 1"
                sizes="(max-width: 1024px) 50vw, 23vw"
              />
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
