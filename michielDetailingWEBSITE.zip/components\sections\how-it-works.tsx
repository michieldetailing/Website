import { Container } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeader } from "@/components/ui/section-header";

const steps = [
  {
    title: "Je stuurt je auto door",
    body: "Merk, model en wat je wilt laten doen. Een paar foto's van de lak en het interieur helpen enorm — daarmee zie ik meteen wat er nodig is.",
  },
  {
    title: "Je krijgt een vaste prijs",
    body: "Binnen een dag hoor je wat het wordt, inclusief reiskosten, en hoe lang ik nodig heb. Geen verrassingen achteraf.",
  },
  {
    title: "Ik kom naar je toe",
    body: "Op de afgesproken dag rijd ik naar je oprit, parkeerplaats of werk. Je hoeft niets te regelen behalve de sleutel.",
  },
  {
    title: "Je krijgt hem terug",
    body: "Ik loop de auto met je langs zodat je ziet wat er gedaan is, en je hoort wat je kunt doen om het zo te houden.",
  },
];

export function HowItWorks() {
  return (
    <section className="bg-surface py-20 lg:py-28">
      <Container>
        <SectionHeader
          eyebrow="Zo werkt het"
          title="Van aanvraag tot schone auto"
          lead="Vier stappen, en alleen de eerste kost jou moeite."
        />

        <ol className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <Reveal key={step.title} as="li" delay={index * 70}>
              <span
                aria-hidden="true"
                className="font-heading block text-[42px] leading-none font-extrabold text-brand-tint"
              >
                {String(index + 1).padStart(2, "0")}
              </span>
              <h3 className="card-title mt-3">{step.title}</h3>
              <p className="mt-2.5 text-[14.5px] leading-relaxed text-ink-dim">
                {step.body}
              </p>
            </Reveal>
          ))}
        </ol>
      </Container>
    </section>
  );
}
