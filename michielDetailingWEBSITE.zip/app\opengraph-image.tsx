import { ImageResponse } from "next/og";

import { site } from "@/lib/site";

export const alt = `${site.name} — mobiele auto detailing in Breda en Goes`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/**
 * Social share card.
 *
 * Generated rather than a static file so it stays in step with lib/site.ts.
 * Kept to system fonts and flat colour: loading a webfont here would add a
 * network round-trip to every card render for a gain nobody sees at
 * thumbnail size.
 */
export default async function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          background: "linear-gradient(150deg, #ffffff 0%, #dfe8f4 100%)",
          padding: "72px 80px",
          fontFamily: "system-ui, sans-serif",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
          <div
            style={{
              width: 84,
              height: 84,
              borderRadius: 18,
              background: "#c7d5e9",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#ffffff",
              fontSize: 46,
              fontWeight: 800,
            }}
          >
            M
          </div>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <span style={{ fontSize: 32, fontWeight: 800, color: "#0f172a" }}>
              {site.name}
            </span>
            <span style={{ fontSize: 20, color: "#1b3a63" }}>
              Mobiele auto detailing
            </span>
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          <span
            style={{
              fontSize: 66,
              fontWeight: 800,
              color: "#0f172a",
              lineHeight: 1.05,
              letterSpacing: "-0.02em",
            }}
          >
            Je auto weer als nieuw.
          </span>
          <span
            style={{
              fontSize: 66,
              fontWeight: 800,
              color: "#1b3a63",
              lineHeight: 1.05,
              letterSpacing: "-0.02em",
            }}
          >
            Bij jou op de oprit.
          </span>
        </div>

        <div style={{ display: "flex", gap: 40, fontSize: 24, color: "#334155" }}>
          <span>Regio Breda &amp; Goes</span>
          <span>Lakcorrectie · Coating · Interieur</span>
        </div>
      </div>
    ),
    size,
  );
}
