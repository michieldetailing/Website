import { Container } from "@/components/ui/container";
import { Reveal } from "@/components/ui/reveal";
import { site } from "@/lib/site";

/**
 * Product lines, as plain wordmarks.
 *
 * Deliberately typographic rather than logo images: reproducing other
 * companies' logos on a commercial site is a trademark question nobody needs,
 * and naming what you work with carries the same trust signal.
 */
export function Brands() {
  return (
    <section className="border-y border-border bg-surface-2 py-12">
      <Container>
        <Reveal className="flex flex-col items-center gap-7">
          <p className="text-[12px] font-bold tracking-[0.18em] text-ink-faint uppercase">
            Ik werk met
          </p>
          <ul className="flex flex-wrap items-center justify-center gap-x-10 gap-y-5">
            {site.brands.map((brand) => (
              <li
                key={brand}
                className="font-heading text-[17px] font-bold tracking-tight text-ink-dim"
              >
                {brand}
              </li>
            ))}
          </ul>
          <p className="max-w-[62ch] text-center text-[13.5px] leading-relaxed text-ink-faint">
            Geen supermarktspul. Producten uit het professionele segment, elk
            voor het doel waarvoor ze gemaakt zijn — een velgreiniger hoort niet
            op je lak en een allesreiniger niet op je leder.
          </p>
        </Reveal>
      </Container>
    </section>
  );
}
