import { PHASE_DEVELOPMENT_SERVER } from "next/constants";
import type { NextConfig } from "next";

/**
 * Builds the Content-Security-Policy.
 *
 * The site talks to no third-party origin at all — no maps, no analytics, no
 * font CDN (next/font self-hosts). So every directive can stay on 'self'.
 *
 * `script-src` still has to allow inline: Next's hydration bootstrap is an
 * inline script, and the nonce alternative forces every page to render
 * dynamically, which would throw away static generation for a brochure site.
 * There is no user-generated HTML anywhere here, so the residual XSS surface
 * is small — revisit if that ever changes.
 *
 * `unsafe-eval` and the localhost websocket are development-only: React's dev
 * build uses eval() for debugging features, and Turbopack pushes hot updates
 * over a websocket. Neither exists in a production build.
 */
function contentSecurityPolicy(isDev: boolean): string {
  const scriptSrc = ["'self'", "'unsafe-inline'", isDev && "'unsafe-eval'"]
    .filter(Boolean)
    .join(" ");

  const connectSrc = ["'self'", isDev && "ws://localhost:* http://localhost:*"]
    .filter(Boolean)
    .join(" ");

  return [
    "default-src 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    "frame-ancestors 'none'",
    "form-action 'self'",
    `script-src ${scriptSrc}`,
    "style-src 'self' 'unsafe-inline'",
    "font-src 'self' data:",
    "img-src 'self' data: blob:",
    `connect-src ${connectSrc}`,
    "upgrade-insecure-requests",
  ].join("; ");
}

/**
 * Exported as a function so the build phase is available. NODE_ENV is not
 * reliable here — it still reads as development while `next start` serves a
 * production build, which would leak `unsafe-eval` into the shipped policy.
 */
export default function config(phase: string): NextConfig {
  const isDev = phase === PHASE_DEVELOPMENT_SERVER;

  const securityHeaders = [
    { key: "Content-Security-Policy", value: contentSecurityPolicy(isDev) },
    { key: "X-Content-Type-Options", value: "nosniff" },
    { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
    { key: "X-Frame-Options", value: "DENY" },
    {
      key: "Permissions-Policy",
      value: "camera=(), microphone=(), geolocation=(), browsing-topics=()",
    },
    {
      key: "Strict-Transport-Security",
      value: "max-age=63072000; includeSubDomains; preload",
    },
  ];

  return {
    reactStrictMode: true,
    poweredByHeader: false,

    images: {
      // Detailing photos are large and photographic — AVIF first.
      formats: ["image/avif", "image/webp"],
    },

    async headers() {
      return [
        { source: "/:path*", headers: securityHeaders },
        {
          // Unhashed filenames, so allow revalidation rather than immutable.
          source: "/assets/:path*",
          headers: [
            {
              key: "Cache-Control",
              value: "public, max-age=3600, stale-while-revalidate=604800",
            },
          ],
        },
      ];
    },
  };
}
