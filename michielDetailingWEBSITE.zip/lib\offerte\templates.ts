import { site, whatsappUrl } from "@/lib/site";

import {
  packageLabel,
  paintConditionLabels,
  vehicleSizeLabels,
  workspaceLabels,
  type QuoteSubmission,
} from "./schema";

export interface MailContent {
  subject: string;
  html: string;
  text: string;
}

/**
 * Escapes text before it goes into an HTML e-mail.
 *
 * Everything here comes from a form a stranger filled in, so it is untrusted
 * by definition — a name containing `<script>` must not become markup in the
 * inbox.
 */
function esc(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function rows(entries: [string, string][]): string {
  return entries
    .filter(([, value]) => value.trim().length > 0)
    .map(
      ([label, value]) => `
        <tr>
          <td style="padding:6px 16px 6px 0;color:#64748b;font-size:13px;vertical-align:top;white-space:nowrap">${esc(
            label,
          )}</td>
          <td style="padding:6px 0;color:#0f172a;font-size:14px">${esc(
            value,
          ).replace(/\n/g, "<br>")}</td>
        </tr>`,
    )
    .join("");
}

function plainRows(entries: [string, string][]): string {
  return entries
    .filter(([, value]) => value.trim().length > 0)
    .map(([label, value]) => `${label}: ${value}`)
    .join("\n");
}

function detailEntries(submission: QuoteSubmission): [string, string][] {
  return [
    ["Type", submission.customerType === "zakelijk" ? "Zakelijk" : "Particulier"],
    ["Naam", submission.name],
    ["Bedrijf", submission.company],
    ["E-mail", submission.email],
    ["Telefoon", submission.phone],
    ["Postcode", submission.postcode],
    ["Plaats", submission.city],
    [
      "Auto",
      [submission.carMake, submission.carModel, submission.carYear]
        .filter(Boolean)
        .join(" "),
    ],
    ["Formaat", vehicleSizeLabels[submission.vehicleSize]],
    ["Pakket", packageLabel(submission.packageSlug)],
    ["Staat van de lak", paintConditionLabels[submission.paintCondition]],
    ["Werkplek", workspaceLabels[submission.workspace]],
    [
      "Voorzieningen",
      [
        submission.hasPower ? "stroom aanwezig" : "geen stroom",
        submission.hasWater ? "water aanwezig" : "geen water",
      ].join(", "),
    ],
    ["Gewenste periode", submission.preferredDate],
    ["Bericht", submission.message],
  ];
}

/** The one that matters: the enquiry landing in Michiel's inbox. */
export function buildNotification(submission: QuoteSubmission): MailContent {
  const entries = detailEntries(submission);
  const car = `${submission.carMake} ${submission.carModel}`.trim();

  const subject = `Offerteaanvraag — ${submission.name} (${car}, ${submission.city})`;

  const html = `
<div style="font-family:system-ui,-apple-system,'Segoe UI',sans-serif;background:#f6f8fb;padding:24px">
  <div style="max-width:640px;margin:0 auto;background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;overflow:hidden">
    <div style="background:#1b3a63;padding:20px 24px">
      <p style="margin:0;color:#c7d5e9;font-size:12px;letter-spacing:.14em;text-transform:uppercase">Nieuwe offerteaanvraag</p>
      <p style="margin:6px 0 0;color:#ffffff;font-size:19px;font-weight:700">${esc(
        submission.name,
      )}${submission.company ? ` — ${esc(submission.company)}` : ""}</p>
    </div>
    <div style="padding:22px 24px">
      <table style="width:100%;border-collapse:collapse">${rows(entries)}</table>
      <p style="margin:22px 0 0;padding-top:16px;border-top:1px solid #e2e8f0;font-size:13px;color:#64748b">
        Beantwoorden gaat rechtstreeks naar
        <a href="mailto:${esc(submission.email)}" style="color:#1b3a63">${esc(
          submission.email,
        )}</a>.
        Bellen: <a href="tel:${esc(submission.phone)}" style="color:#1b3a63">${esc(
          submission.phone,
        )}</a>.
      </p>
    </div>
  </div>
</div>`.trim();

  const text = `Nieuwe offerteaanvraag\n\n${plainRows(entries)}`;

  return { subject, html, text };
}

/**
 * Confirmation to the customer.
 *
 * Doubles as the prompt for photographs: the form deliberately has no upload
 * field, so this mail is where the request for pictures lands — with a
 * WhatsApp link that makes sending them from a phone one tap.
 */
export function buildAutoReply(submission: QuoteSubmission): MailContent {
  const firstName = submission.name.split(" ")[0] ?? submission.name;
  const car = `${submission.carMake} ${submission.carModel}`.trim();

  const subject = `Je aanvraag is binnen — ${site.name}`;

  const html = `
<div style="font-family:system-ui,-apple-system,'Segoe UI',sans-serif;background:#f6f8fb;padding:24px">
  <div style="max-width:600px;margin:0 auto;background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;overflow:hidden">
    <div style="background:#1b3a63;padding:22px 26px">
      <p style="margin:0;color:#ffffff;font-size:20px;font-weight:700">${esc(
        site.name,
      )}</p>
      <p style="margin:5px 0 0;color:#c7d5e9;font-size:13px">Mobiele auto detailing · Breda &amp; Goes</p>
    </div>
    <div style="padding:26px">
      <p style="margin:0 0 16px;font-size:15px;line-height:1.65;color:#0f172a">Hoi ${esc(
        firstName,
      )},</p>
      <p style="margin:0 0 16px;font-size:15px;line-height:1.65;color:#334155">
        Je aanvraag voor je ${esc(
          car,
        )} is binnengekomen. Ik kijk ernaar en stuur je binnen één werkdag een
        prijs, inclusief reiskosten naar ${esc(submission.city)}.
      </p>
      <p style="margin:0 0 8px;font-size:15px;line-height:1.65;color:#334155">
        <strong style="color:#0f172a">Wil je het proces versnellen?</strong>
        Stuur me een paar foto's van de lak en het interieur via WhatsApp. Bij
        daglicht en van een hoek waarop je de reflectie ziet — dan kan ik veel
        preciezer inschatten wat je auto nodig heeft.
      </p>
      <p style="margin:20px 0 24px">
        <a href="${whatsappUrl}" style="display:inline-block;background:#1b3a63;color:#ffffff;text-decoration:none;padding:12px 22px;border-radius:999px;font-size:14px;font-weight:600">Foto's sturen via WhatsApp</a>
      </p>
      <p style="margin:0;padding-top:18px;border-top:1px solid #e2e8f0;font-size:13.5px;line-height:1.7;color:#64748b">
        Liever bellen? ${esc(site.phoneDisplay)}<br>
        Michiel — ${esc(site.name)}<br>
        KvK ${esc(site.kvk)} · btw ${esc(site.vat)}
      </p>
    </div>
  </div>
</div>`.trim();

  const text = [
    `Hoi ${firstName},`,
    "",
    `Je aanvraag voor je ${car} is binnengekomen. Ik kijk ernaar en stuur je binnen één werkdag een prijs, inclusief reiskosten naar ${submission.city}.`,
    "",
    "Wil je het proces versnellen? Stuur me een paar foto's van de lak en het interieur via WhatsApp, bij daglicht en van een hoek waarop je de reflectie ziet.",
    whatsappUrl,
    "",
    `Liever bellen? ${site.phoneDisplay}`,
    `Michiel — ${site.name}`,
    `KvK ${site.kvk} · btw ${site.vat}`,
  ].join("\n");

  return { subject, html, text };
}
